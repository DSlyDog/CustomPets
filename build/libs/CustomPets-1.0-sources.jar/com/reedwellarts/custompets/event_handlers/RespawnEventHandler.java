package com.reedwellarts.custompets.event_handlers;

import com.reedwellarts.custompets.event_handlers.state.PetTrackingState;
import com.reedwellarts.custompets.pet.core.interfaces.OwnablePet;
import com.reedwellarts.custompets.pet.data.PlayerPetTracking;
import com.reedwellarts.custompets.pet.entities.PetFoxEntity;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3730;
import net.minecraft.class_5134;
import net.minecraft.class_7923;
import net.minecraft.server.MinecraftServer;
import java.util.ArrayList;
import java.util.List;

public class RespawnEventHandler {

    public static void handlePetRespawn(MinecraftServer server){
        for (class_3218 world : server.method_3738()){
            PetTrackingState state = PetTrackingState.get(world);
            long now = world.method_75260();

            List<PetTrackingState.Entry> due = new ArrayList<>();
            for (PetTrackingState.Entry entry : state.entries()){
                if (entry.respawnAt <= now){
                    class_3222 owner = server.method_3760().method_14602(entry.ownerUuid);
                    if (owner == null) continue;

                    class_2960 id = class_2960.method_12829(entry.petTypeId);
                    if (id == null) continue;

                    class_1299 type = class_7923.field_41177.method_63535(id);
                    if (type == null) continue;

                    class_1309 living = buildEntity(entry, world, owner);

                    world.method_8649(living);
                    due.add(entry);
                }
            }
            state.removeMultiple(due);
        }
    }

    public static class_1309 buildEntity(PetTrackingState.Entry entry, class_3218 world, class_3222 owner){
        class_1297 loadedEntity = class_1299.method_71371(
                entry.petNbt, world, class_3730.field_16467, entity -> {
                    entity.method_5808(owner.method_23317() + 1, owner.method_23318(), owner.method_23321() + 1, owner.method_36454(), 0f);
                    return entity;
                }
        );
        if (!(loadedEntity instanceof class_1309 living)) return null;

        if (living instanceof OwnablePet pet) {
            pet.getDelegate().setPetOwnerUuid(owner.method_5667());
            pet.setPetSitting(false);
            living.method_5996(class_5134.field_23716).method_6192(pet.getDelegate().getDataManager().getData().maxHealth);
            living.method_6033(living.method_6063());
            pet.getDelegate().setPetHealth((int) living.method_6063());
            living.method_18800(living.method_18798().field_1352, 0, living.method_18798().field_1350);

            if (!PlayerPetTracking.playerAtMaxPets(owner.method_5667()) && !PlayerPetTracking.playerAtMaxActive(owner.method_5667())){
                PlayerPetTracking.respawnPet(owner.method_5667(), loadedEntity.method_5667());
            }
        }

        if (entry.customNameJson != null && !entry.customNameJson.isBlank()){
            living.method_5665(class_2561.method_43470(entry.customNameJson));
            living.method_5880(true);
        }

        if (living instanceof PetFoxEntity foxPet && entry.petVariant != null){
            foxPet.applySavedVariant(entry.petVariant.toUpperCase());
        }

        return living;
    }
}
