package com.reedwellarts.custompets.event_handlers;

import com.reedwellarts.custompets.event_handlers.state.PetTrackingState;
import com.reedwellarts.custompets.pet.converters.FoxPetConverter;
import com.reedwellarts.custompets.pet.core.interfaces.OwnablePet;
import com.reedwellarts.custompets.pet.core.interfaces.PetConverter;
import com.reedwellarts.custompets.pet.data.PlayerPetTracking;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_11362;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_3218;
import net.minecraft.class_3730;
import net.minecraft.class_3966;
import net.minecraft.class_8942;

public class TameEntityEventHandler {

    private static final Map<class_1299<?>, PetConverter<?, ?>> CONVERTERS = Map.of(
            class_1299.field_17943, new FoxPetConverter()
            //EntityType.ENDER_DRAGON, new DragonPetConverter()
    );

    public static class_1269 handleUseEntity(class_1657 player, class_1937 world, class_1268 hand, class_1297 entity, class_3966 hitResult) {
        if (world.method_8608()) return class_1269.field_5811;
        if (hand != class_1268.field_5808) return class_1269.field_5811;
        if (!player.method_6047().method_31574(class_1802.field_8600)) return class_1269.field_5811;

        if (!(entity instanceof class_1309 living)) return class_1269.field_5811;

        PetConverter<?, ?> raw = CONVERTERS.get(living.method_5864());
        if (raw == null) return class_1269.field_5811;

        return convert(player, world, living, raw);
    }

    @SuppressWarnings("unchecked")
    private static <S extends class_1309, P extends class_1309 & OwnablePet>
    class_1269 convert(class_1657 player, class_1937 world, class_1309 srcAny, PetConverter<?, ?> raw){
        PetConverter<S, P> converter = (PetConverter<S, P>) raw;
        S src = (S) srcAny;

        P pet = converter.petType().method_5883(world, class_3730.field_16468);
        if (pet == null) return class_1269.field_5811;

        converter.copyCommon(src, pet, player);
        converter.copySpecific(src, pet);

        boolean success = registerPet(pet, player.method_5667(), pet.method_5667(), (class_3218) world);
        if (!success) {
            return class_1269.field_5811;
        }

        world.method_8649(pet);
        src.method_31472();
        return class_1269.field_5812;
    }

    private static boolean registerPet(class_1309 pet, UUID player, UUID petUuid, class_3218 world){
        PetTrackingState trackingState = PetTrackingState.get(world);
        if (!trackingState.playerAtMaxPets(player) && !trackingState.playerAtMaxActive(player)){
            trackingState.addActivePet(player, petUuid);

            PetTrackingState.Entry entry = new PetTrackingState.Entry();
            if (pet.method_16914())
                entry.customNameJson = pet.method_5797().getString();
            entry.ownerUuid = player;
            entry.petTypeId = class_1299.method_5890(pet.method_5864()).toString();
            entry.petUuid = pet.method_5667();
            class_11362 view = class_11362.method_71458(class_8942.field_60348);
            pet.method_5647(view);
            class_2487 nbt = view.method_71475();
            nbt.method_10582("id", class_1299.method_5890(pet.method_5864()).toString());
            entry.petNbt = nbt;

            trackingState.addPlayerPet(player,  entry);
            trackingState.addPetEntity(player, (OwnablePet) pet);
            return true;
        }

        return false;
    }
}
