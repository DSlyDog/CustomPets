package com.reedwellarts.custompets.event_handlers.state;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.reedwellarts.custompets.CustomPets;
import com.reedwellarts.custompets.event_handlers.RespawnEventHandler;
import com.reedwellarts.custompets.pet.core.interfaces.OwnablePet;
import org.jspecify.annotations.Nullable;

import java.util.*;
import net.minecraft.class_10741;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_18;
import net.minecraft.class_2487;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_4844;

public class PetTrackingState extends class_18 {

    public static class Entry{
        public UUID ownerUuid;
        public UUID petUuid;
        public String petTypeId;
        public long respawnAt;
        public @Nullable String customNameJson;
        public @Nullable String petVariant;
        public class_2487 petNbt;

        public static final Codec<Entry> CODEC = RecordCodecBuilder.create(instance -> instance.group(
                class_4844.field_40825.fieldOf("owner_uuid").forGetter(e -> e.ownerUuid),
                class_4844.field_40825.fieldOf("pet_uuid").forGetter(e -> e.petUuid),
                Codec.STRING.fieldOf("pet_type_id").forGetter(e -> e.petTypeId),
                Codec.LONG.fieldOf("respawn_at").forGetter(e -> e.respawnAt),
                Codec.STRING.optionalFieldOf("custom_name_json", "")
                        .forGetter(e -> e.customNameJson == null ? "" : e.customNameJson),
                Codec.STRING.optionalFieldOf("pet_variant", "")
                        .forGetter(e -> e.petVariant == null ? "" : e.petVariant),
                class_2487.field_25128.fieldOf("pet_nbt").forGetter(e -> e.petNbt)
        ).apply(instance, (ownerUuid, petUuid, petTypeId, respawnAt, customNameJson, petVariant, petNbt) -> {
            Entry e = new Entry();
            e.ownerUuid = ownerUuid;
            e.petUuid = petUuid;
            e.petTypeId = petTypeId;
            e.respawnAt = respawnAt;
            e.customNameJson = customNameJson.isEmpty() ? null : customNameJson;
            e.petVariant = petVariant.isEmpty() ? null : petVariant;
            e.petNbt = petNbt.method_33133() ? null : petNbt;
            return e;
        }));
    }

    private static final String SAVE_ID = CustomPets.MOD_ID + "_links";
    private static final Codec<PetTrackingState> CODEC = RecordCodecBuilder.create(instance -> instance.group(
       Entry.CODEC.listOf().fieldOf("entries").forGetter(state -> state.entries)
    ).apply(instance, list -> {
        PetTrackingState state = new PetTrackingState();
        state.entries.addAll(list);
        return state;
    }));
    private static final class_10741<PetTrackingState> TYPE = new class_10741<>(
            SAVE_ID,
            PetTrackingState::new,
            CODEC,
            null
    );

    private static final int MAX_TAMED_PETS = 20;
    private static final int MAX_ACTIVE_PETS = 4;

    private final List<Entry> entries = new ArrayList<>();
    private final Map<UUID, List<Entry>> playerPets = new HashMap<>();
    private final Map<UUID, List<OwnablePet>> playerPetEntities = new HashMap<>();
    private final Map<UUID, List<UUID>> playerActivePets = new HashMap<>();

    public static PetTrackingState get(class_3218 world){
        return world.method_17983().method_17924(TYPE);
    }

    public void add(Entry e){
        entries.add(e);
        method_80();
    }

    public List<Entry> entries(){
        return entries;
    }

    public void removeMultiple(List<Entry> due){
        this.entries.removeAll(due);
        method_80();
    }

    public void addPlayerPet(UUID playerUuid, Entry e){
        if (this.playerPets.containsKey(playerUuid)) {
            this.playerPets.get(playerUuid).add(e);
        }else{
            List<Entry> pets = new ArrayList<>();
            pets.add(e);
            this.playerPets.put(playerUuid, pets);
        }
        method_80();
    }

    public void addActivePet(UUID playerUuid, UUID petUuid){
        if (!this.playerActivePets.containsKey(playerUuid)){
            List<UUID> pets = new ArrayList<>();
            this.playerActivePets.put(playerUuid, pets);
        }

        playerActivePets.get(playerUuid).add(petUuid);
    }

    public void addPetEntity(UUID playerUuid, OwnablePet pet){
        if (!this.playerPetEntities.containsKey(playerUuid)){
            List<OwnablePet> pets = new ArrayList<>();
            this.playerPetEntities.put(playerUuid, pets);
        }

        this.playerPetEntities.get(playerUuid).add(pet);
    }

    public Entry getPlayerPet(UUID playerUuid, UUID petUuid){
        if (!this.playerPets.containsKey(playerUuid)) return null;

        List<Entry> pets = playerPets.get(playerUuid);

        for (Entry pet : pets){
            if (pet.petUuid.equals(petUuid)){
                return pet;
            }
        }
        return null;
    }

    public List<Entry> getPlayerPets(UUID playerUuid){
        if (!this.playerPets.containsKey(playerUuid)){
            List<Entry> entries = new ArrayList<>();
            this.playerPets.put(playerUuid, entries);
        }

        return this.playerPets.get(playerUuid);
    }

    public List<OwnablePet> getPlayerPetEntities(UUID playerUuid){
        if (!this.playerPetEntities.containsKey(playerUuid)){
            List<OwnablePet> ownables = new ArrayList<>();
            this.playerPetEntities.put(playerUuid, ownables);
        }

        return this.playerPetEntities.get(playerUuid);
    }

    public boolean isActivePet(UUID playerUuid, UUID petUuid){
        if (!this.playerActivePets.containsKey(playerUuid)){
            List<UUID> entries = new ArrayList<>();
            this.playerActivePets.put(playerUuid, entries);
        }

        return this.playerActivePets.get(playerUuid).contains(petUuid);
    }

    public void updateActivePets(UUID ownerUuid, List<String> petUuids, class_3218 world){
        if (!this.playerActivePets.containsKey(ownerUuid)){
            List<UUID> petList = new ArrayList<>();
            this.playerActivePets.put(ownerUuid, petList);
        }

        List<UUID> currentActive = this.playerActivePets.get(ownerUuid);
        List<UUID> newUuids = new ArrayList<>();

        for (String stringUuid : petUuids){
            newUuids.add(UUID.fromString(stringUuid));
        }

        this.playerActivePets.put(ownerUuid, newUuids);

        for (UUID uuid : currentActive){
            if (!newUuids.contains(uuid)) {
                class_1297 entity = world.method_66347(uuid);
                if (entity != null) entity.method_31472();
            }
        }

        class_3222 owner = (class_3222) world.method_18470(ownerUuid);

        CustomPets.LOGGER.info("Pet entities size: {}", this.playerPetEntities.get(ownerUuid));

        for (OwnablePet pet : this.playerPetEntities.get(ownerUuid)){
            class_1309 livingPet = (class_1309) pet;
            if (!currentActive.contains(livingPet.method_5667()) && newUuids.contains(livingPet.method_5667())){
                livingPet.method_5808(owner.method_23317() + 1, owner.method_23318(), owner.method_23321() + 1, owner.method_36454(), 0f);
                livingPet.method_18800(livingPet.method_18798().field_1352, 0, livingPet.method_18798().field_1350);
                pet.unsetPetRemoved();
                world.method_8649(livingPet);
            }
        }

        method_80();
    }

    public boolean playerAtMaxPets(UUID player){
        if (!playerPets.containsKey(player)) playerPets.put(player, new ArrayList<>());
        return playerPets.get(player).size() >= MAX_TAMED_PETS;
    }

    public boolean playerAtMaxActive(UUID player){
        if (!playerActivePets.containsKey(player)) playerActivePets.put(player, new ArrayList<>());
        return playerActivePets.get(player).size() >= MAX_ACTIVE_PETS;
    }
}
