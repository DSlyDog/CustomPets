package com.reedwellarts.custompets.event_handlers;

import com.reedwellarts.custompets.CustomPets;
import com.reedwellarts.custompets.pet.core.interfaces.OwnablePet;
import com.reedwellarts.custompets.pet.data.PlayerPetTracking;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

public class PlayerDamageEventHandler {

    private static final Set<UUID> damageGuard = new HashSet<>();

    public static boolean handlePlayerDamage(class_1309 livingEntity, class_1282 damageSource, float damageTaken) {
        if (!(livingEntity instanceof class_3222 player)) return true;
        if (damageGuard.contains(player.method_5667())) return true;

        for (UUID petUuid : PlayerPetTracking.getPlayerActivePets(player.method_5667())){
            class_1297 entity = player.method_51469().method_66347(petUuid);

            if (entity instanceof OwnablePet pet && pet.getDelegate().getDataManager().getData().isGuardian){
                damageTaken = damageTaken / 2;

                damageGuard.add(player.method_5667());
                try {
                    pet.getDelegate().doDamage((class_1308) pet, player.method_51469(), damageSource, damageTaken);
                    player.method_64397(player.method_51469(), damageSource, damageTaken);
                } finally {
                    damageGuard.remove(player.method_5667());
                }
                return false;
            }

            if (entity instanceof OwnablePet pet && entity instanceof class_1309 petEntity && pet.getDelegate().getDataManager().getData().isAngel){
                if (damageTaken >= player.method_6032() && pet.getDelegate().doSacrifice()){
                    player.method_6033(player.method_6063());
                    petEntity.method_6033(0);
                    petEntity.method_6078(player.method_51469().method_48963().method_48830());
                    class_2561 name = petEntity.method_16914() ? petEntity.method_5797() : petEntity.method_5477();
                    player.method_64398(class_2561.method_43470(name.getString() + " died to save you"));
                    return false;
                }
            }
        }
        return true;
    }
}
