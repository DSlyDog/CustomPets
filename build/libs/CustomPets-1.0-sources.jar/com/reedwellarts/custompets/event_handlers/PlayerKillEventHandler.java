package com.reedwellarts.custompets.event_handlers;

import com.reedwellarts.custompets.CustomPets;
import com.reedwellarts.custompets.pet.core.interfaces.OwnablePet;
import com.reedwellarts.custompets.pet.data.PlayerPetTracking;
import java.util.List;
import java.util.UUID;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_3222;

public class PlayerKillEventHandler {

    public static void handleAfterDeath(class_1297 entity, class_1282 source){
        if (source.method_5529() instanceof class_3222 player){
            List<UUID> ownablePets = PlayerPetTracking.getPlayerActivePets(player.method_5667());
            for (UUID petUuid : ownablePets){
                class_1297 petEntity = player.method_51469().method_66347(petUuid);
                if (petEntity instanceof OwnablePet pet) {
                    boolean petHit = pet.getDelegate().onPlayerKilledTarget(entity);
                }
            }
        }
    }
}
