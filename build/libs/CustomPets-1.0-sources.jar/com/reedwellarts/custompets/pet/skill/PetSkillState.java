package com.reedwellarts.custompets.pet.skill;

import java.util.HashSet;
import java.util.Set;
import net.minecraft.class_2960;

public class PetSkillState {
    public static final int MAX_ACTIVE = 4;

    private final Set<class_2960> unlocked = new HashSet<>();
    private  final Set<class_2960> active = new HashSet<>();

    public boolean isUnlocked(class_2960 id){
        return unlocked.contains(id);
    }

    public boolean isActive(class_2960 id){
        return active.contains(id);
    }

    public Set<class_2960> getUnlocked() {
        return Set.copyOf(unlocked);
    }

    public Set<class_2960> getActive() {
        return Set.copyOf(active);
    }

    public boolean unlock(class_2960 id){
        return unlocked.add(id);
    }

    public boolean activate(class_2960 id){
        if (!unlocked.contains(id)) return false;
        if (isActive(id)) return true;
        if (active.size() >= MAX_ACTIVE) return false;
        return active.add(id);
    }

    public boolean deactivate(class_2960 id){
        return active.remove(id);
    }

    public void clear(){
        unlocked.clear();
        active.clear();
    }
}
