package com.reedwellarts.custompets.pet.skill;

import com.reedwellarts.custompets.CustomPets;
import com.reedwellarts.custompets.pet.core.interfaces.Skill;
import com.reedwellarts.custompets.pet.skill.skills.*;
import org.jetbrains.annotations.Nullable;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Supplier;
import net.minecraft.class_2960;

public class SkillRegistry {

    public static final Map<class_2960, Supplier<Skill>> REGISTRY = new HashMap<>();

    public static final class_2960 MOUNT = register("mount", MountSkill::new);
    public static final class_2960 DAMAGE_DEALER = register("damage_dealer", DamageDealerSkill::new);
    public static final class_2960 FLYING_MOUNT = register("flying_mount", FlyingMountSkill::new);
    public static final class_2960 BACKPACK_BUDDY = register("backpack_buddy", BackpackBuddySkill::new);
    public static final class_2960 GUARDIAN = register("guardian", GuardianSkill::new);
    public static final class_2960 ANGEL = register("angel", AngelSkill::new);

    private static class_2960 register(String path, Supplier<Skill> factory){
        class_2960 id = class_2960.method_60655(CustomPets.MOD_ID, path);
        REGISTRY.put(id, factory);
        return id;
    }

    public static @Nullable Skill create(class_2960 id) {
        Supplier<Skill> factory = REGISTRY.get(id);
        return factory == null ? null : factory.get();
    }
}
