package com.reedwellarts.custompets.pet.data;

import net.minecraft.class_11368;
import net.minecraft.class_11372;

public class PetData {

    public static final int MAX_LEVEL = 100;

    public String name = "";
    public int xp = 0;
    public int xpToNextLevel = 30;
    public int level = 1;
    public int health = 20;
    public int maxHealth = 20;
    public int inventoryRows = 1;

    public double maxHealthMultiplier = 1;
    public double attackPowerMultiplier = 1;
    public boolean isRideable = false;
    public boolean isFlyable = false;
    public boolean hasInventory = false;
    public boolean isGuardian = false;
    public boolean isAngel = false;

    public void writeCustomData(class_11372 view){
        view.method_71469("PetName", name);
        view.method_71465("PetXp", xp);
        view.method_71465("PetXpToNextLevel", xpToNextLevel);
        view.method_71465("PetLevel", level);
        view.method_71465("PetHealth", health);
        view.method_71465("PetInventoryRows", inventoryRows);
    }

    public void readCustomData(class_11368 view){
        this.name = view.method_71428("PetName", "");
        this.xp = view.method_71424("PetXp", 0);
        this.xpToNextLevel = view.method_71424("PetXpToNextLevel", 0);
        this.level = view.method_71424("PetLevel", 1);
        this.health = view.method_71424("PetHealth", 20);
        this.inventoryRows = view.method_71424("PetInventoryRows", 1);
    }
}
