package com.reedwellarts.custompets.pet.data;

import com.mojang.serialization.Codec;
import com.reedwellarts.custompets.CustomPets;
import com.reedwellarts.custompets.items.item.PetWand;
import com.reedwellarts.custompets.pet.core.enums.SkillCategory;
import com.reedwellarts.custompets.pet.core.interfaces.OwnablePet;
import com.reedwellarts.custompets.event_handlers.state.PetTrackingState;
import com.reedwellarts.custompets.items.ItemRegistry;
import com.reedwellarts.custompets.pet.core.interfaces.Skill;
import com.reedwellarts.custompets.pet.skill.SkillRegistry;
import org.jspecify.annotations.Nullable;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.Supplier;
import net.minecraft.class_11362;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1277;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1707;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3917;
import net.minecraft.class_5134;
import net.minecraft.class_6067;
import net.minecraft.class_747;
import net.minecraft.class_8942;

public class PetDelegate<T extends class_1308 & OwnablePet & class_6067> {

    private UUID ownerUuid;

    private final PetDataManager dataManager = new PetDataManager();

    private static final int KILL_XP = 20;
    private static final int HIT_XP = 15;
    private static final int RIDE_PASSIVE_XP = 7;
    private static final int INVENTORY_PASSIVE_XP = 7;
    private static final double DISTANCE_FOR_RIDE_XP = 300;
    private static final int ATTACK_DAMAGE_BASE= 2;

    private double distanceRidden = 0;
    private float inventoryUsageCount = 0;
    private int purgeTicker = 0;
    private int sacrificeTicker = 0;
    private boolean hasSacrificed = false;
    private class_2338 lastPos;
    private class_1792 healItem;
    private boolean isGrounded = false;

    private final Set<UUID> recentlyHit = new HashSet<>();

    public PetDelegate(T entity, class_1792 healItem){
        this.healItem = healItem;

        for (Map.Entry<class_2960, Supplier<Skill>> entry : SkillRegistry.REGISTRY.entrySet()){
            dataManager.unlockSkill(entry.getKey());
        }

        entity.method_5996(class_5134.field_23716).method_6192(dataManager.getData().maxHealth);
        entity.method_5996(class_5134.field_23721).method_6192(ATTACK_DAMAGE_BASE * dataManager.getData().attackPowerMultiplier);
        entity.method_6033(dataManager.getData().maxHealth);
    }

    public UUID getPetOwnerUuid() {
        return ownerUuid;
    }

    public void setPetOwnerUuid(@Nullable UUID uuid) {
        this.ownerUuid = uuid;
    }

    public void setPetName(String name){
        dataManager.setName(name);
    }

    public void setPetHealth(int health){
        dataManager.setHealth(health);
    }

    public void setPetMaxHealth(T pet, int maxHealth){
        dataManager.setMaxHealth(maxHealth);
        pet.method_5996(class_5134.field_23716)
                .method_6192(maxHealth);
    }

    public PetDataManager getDataManager(){
        return dataManager;
    }

    public class_243 travel(T entity, class_243 movementInput) {
        if (entity.method_5782() && entity.method_5642() instanceof class_1657 rider){
            entity.method_36456(rider.method_36454());
            entity.method_36457(rider.method_36455() * 0.5f);
            entity.field_6283 = entity.method_73188();
            entity.field_6241 = entity.field_6283;

            float strafe = rider.field_6212 * 0.5f;
            float forward = rider.field_6250;
            if (forward < 0.0F) forward *= 0.25f;

            if (entity.isFlyable()){
                entity.method_5875(true);
                float speed = (float) entity.method_45325(class_5134.field_23719) * 2f;

                if (rider.method_70673()) {
                    isGrounded = false;
                    entity.method_18800(entity.method_18798().field_1352, speed, entity.method_18798().field_1350);
                }
                else if (entity.isFlightDescending()) {
                    entity.method_18800(entity.method_18798().field_1352, -speed, entity.method_18798().field_1350);
                }
                else {
                    entity.method_18800(entity.method_18798().field_1352, 0.0, entity.method_18798().field_1350);
                }
            }else{
                entity.method_5875(false);
            }

            if (rider.method_70673() && entity.method_24828()){
                entity.method_18800(entity.method_18798().field_1352, 0.6D, entity.method_18798().field_1350);
            }

            entity.method_6125((float) entity.method_45325(class_5134.field_23719) * 2F);
            return new class_243(strafe, entity.field_6227 / 2, forward);
        }

        return movementInput;
    }

    public boolean onFall(T entity){
        if (entity.isFlyable()) return true;
        return false;
    }

    public void dismountPlayer(T entity){
        entity.method_5772();
        isGrounded = true;
    }

    public boolean canTrust(class_1309 entity) {
        return this.getPetOwnerUuid().equals(entity.method_5667());
    }

    public void tick(T entity){
        if (entity.isPetSitting()){
            entity.method_5942().method_6340();
            entity.method_18800(0.0, entity.method_18798().field_1351, 0.0);
        }

        purgeTicker++;
        if (purgeTicker >= 1200){
            purgeTicker = 0;
            recentlyHit.clear();
        }

        if (hasSacrificed) {
            sacrificeTicker++;
            if (sacrificeTicker >= 6000) {
                sacrificeTicker = 0;
                hasSacrificed = false;
            }
        }

        if (entity.method_5782()){
            if (entity.method_5642() instanceof class_3222 rider){
                if (!isGrounded){
                    rider.method_5660(false);
                }
            }
        }

        tickPassiveRideXp(entity);
    }

    public void tickPassiveRideXp(T entity){
        class_2338 currentPos = entity.method_24515();

        if (lastPos != null){
            distanceRidden += Math.sqrt(currentPos.method_10262(lastPos));
            if (distanceRidden >= DISTANCE_FOR_RIDE_XP){
                dataManager.awardXp(RIDE_PASSIVE_XP, SkillCategory.PASSIVE);
                distanceRidden = 0;
            }

        }

        lastPos = currentPos;

        if (!entity.method_5782()) lastPos = null;
    }

    public class_1269 interactMob(T entity, class_1657 player, class_1268 hand) {
        if (entity.method_73183().method_8608()){
            return class_1269.field_5812;
        }

        if (player.method_5667().equals(this.getPetOwnerUuid())){
            if (player.method_5998(hand).method_31574(ItemRegistry.PET_NAME_TAG)){
                return class_1269.field_5811;
            }

            if (player.method_5998(hand).method_31574(this.healItem)){
                entity.method_6033(entity.method_6032() + entity.method_6063() * 0.25f);
                dataManager.getData().health = (int) entity.method_6032();
                return class_1269.field_21466;
            }

            if (player.method_5998(hand).method_31574(class_1802.field_8600)){
                class_3222 serverPlayer = (class_3222) player;
                PetWand.openRosterScreen(serverPlayer, serverPlayer.method_51469());
                return class_1269.field_5811;
            }

            if (player.method_5998(hand).method_31574(class_1802.field_8287)){
                dataManager.awardXp(1000000, SkillCategory.PASSIVE);
            }

            if (dataManager.hasInventory() && !player.method_5715()){
                class_3917<?> handlerType = switch (dataManager.getData().inventoryRows) {
                    case 2 -> class_3917.field_18665;
                    case 3 -> class_3917.field_17326;
                    case 4 -> class_3917.field_18666;
                    case 5 -> class_3917.field_18667;
                    case 6 -> class_3917.field_17327;
                    default -> class_3917.field_18664;
                };

                player.method_17355(new class_747((syncId, playerInventory, player1) ->
                        new class_1707(
                                        handlerType, syncId, playerInventory, entity.method_35199(), 1
                                ),
                        class_2561.method_43470(entity.method_5477().getString() + "'s Inventory")
                        )
                );
                return class_1269.field_5812;
            }

            if (player.method_5998(hand).method_31574(class_1802.field_8175)){
                if (dataManager.isRideable()){
                    entity.setPetSitting(false);
                    player.method_5873(entity, true, true);
                    return class_1269.field_21466;
                }
            }

            entity.setPetSitting(!entity.isPetSitting());
            return class_1269.field_21466;
        }

        return null;
    }

    public class_1277 updateInventory(T entity){
        CustomPets.LOGGER.info("Current Inventory Size: {}", entity.method_35199().method_5439());
        CustomPets.LOGGER.info("Inventory rows: {}", dataManager.getData().inventoryRows);
        if (entity.method_35199().method_5439() < dataManager.getInventoryRows() * 9){
            class_1277 newInv = new class_1277(dataManager.getInventoryRows() * 9);
            class_1277 currentInv = entity.method_35199();
            for (int i = 0; i < entity.method_35199().method_5439(); i++){
                newInv.method_5447(i, currentInv.method_5438(i));
            }
            CustomPets.LOGGER.info("Returning newInv from updateInventory func");
            return newInv;
        }
        return null;
    }

    public void tryAttack(T entity, boolean result, class_1297 target){
        recentlyHit.add(target.method_5667());
        if (result && target instanceof class_1309 living){
            CustomPets.LOGGER.info("Pet hit target");
            if (living.method_29504() || living.method_6032() <= 0){
                dataManager.awardXp(KILL_XP, SkillCategory.COMBAT);
            }
        }

        entity.method_5996(class_5134.field_23721).method_6192(ATTACK_DAMAGE_BASE * dataManager.getAttackPowerMultiplier());
    }

    public boolean onPlayerKilledTarget(class_1297 target){
        if (recentlyHit.contains(target.method_5667())){
            dataManager.awardXp(HIT_XP, SkillCategory.COMBAT);
            return true;
        }

        return false;
    }

    public boolean onDamage(T self, class_1282 damageSource){
        if (damageSource.method_5529() instanceof class_3222 player){
            if (player.method_5667().equals(this.getPetOwnerUuid())) return false;
        }

        return true;
    }

    public void doDamage(T entity, class_3218 world, class_1282 source, float amount){
        entity.method_64397(world, source, amount);
    }

    public PetTrackingState.Entry onDeath(T entity, class_1282 damageSource) {
        if (!entity.method_73183().method_8608()){
            CustomPets.LOGGER.info("Running pet death event");
            UUID owner = this.getPetOwnerUuid();
            if (owner != null && entity.method_73183() instanceof class_3218 serverWorld){
                PetTrackingState state = PetTrackingState.get(serverWorld);
                PetTrackingState.Entry entry = new PetTrackingState.Entry();
                entry.ownerUuid = owner;
                entry.petTypeId = class_1299.method_5890(entity.method_5864()).toString();
                entry.respawnAt = serverWorld.method_75260() + 20L * 30L;
                class_11362 view = class_11362.method_71458(class_8942.field_60348);
                entity.method_5647(view);
                class_2487 nbt = view.method_71475();
                nbt.method_10582("id", class_1299.method_5890(entity.method_5864()).toString());
                entry.petNbt = nbt;
                if (entity.method_16914()){
                    entry.customNameJson = entity.method_5797().getString();
                }

                state.add(entry);

                CustomPets.LOGGER.info("Added pet to respawn state");
                class_1657 ownerPlayer = serverWorld.method_18470(ownerUuid);
                if (ownerPlayer != null){
                    ownerPlayer.method_7353(damageSource.method_5506(entity), false);
                }
                return entry;
            }
        }
        return null;
    }

    public boolean doSacrifice(){
        if (hasSacrificed){
            return false;
        }

        hasSacrificed = true;
        return true;
    }

    public void writeCustomData(T entity, class_11372 view) {
        if (this.ownerUuid != null){
            view.method_71469("PetOwnerUuid", this.ownerUuid.toString());
        }

        view.method_71472("PetSitting", entity.isPetSitting());

        var unlockedAppender = view.method_71467("PetSkillsUnlocked", Codec.STRING);
        for (class_2960 id : dataManager.getSkillState().getUnlocked()){
            unlockedAppender.method_71484(id.toString());
        }

        var activeAppender = view.method_71467("PetSkillsActive", Codec.STRING);
        for (class_2960 id : dataManager.getSkillState().getActive()){
            activeAppender.method_71484(id.toString());
        }

        dataManager.getData().writeCustomData(view);
    }

    public void readCustomData(T entity, class_11368 view) {
        this.ownerUuid = view.contains("PetOwnerUuid") ? UUID.fromString(view.method_71428("PetOwnerUuid", "")) : null;
        entity.setPetSitting(view.method_71433("PetSitting", false));

        dataManager.getData().readCustomData(view);

        dataManager.getSkillState().clear();

        view.method_71435("PetSkillsUnlocked", Codec.STRING)
                .ifPresent(list -> {
                    for (int i=0; i<list.method_71456().toArray().length; i++){
                        String raw = (String) list.method_71456().toArray()[i];
                        class_2960 id = class_2960.method_12829(raw);
                        if (id != null){
                            dataManager.unlockSkill(id);
                        }
                    }
                });

        view.method_71435("PetSkillsActive", Codec.STRING)
                .ifPresent(list -> {
                    for (int i=0; i<list.method_71456().toArray().length; i++){
                        String raw = (String) list.method_71456().toArray()[i];
                        class_2960 id = class_2960.method_12829(raw);
                        if (id != null){
                            dataManager.activateSkill(id);
                        }
                    }
                });

        PlayerPetTracking.respawnPet(this.getPetOwnerUuid(), entity.method_5667());
    }
}
