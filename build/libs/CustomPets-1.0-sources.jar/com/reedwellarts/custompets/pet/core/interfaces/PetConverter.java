package com.reedwellarts.custompets.pet.core.interfaces;

import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1657;

public interface PetConverter<S extends class_1309, P extends class_1309 & OwnablePet> {
    class_1299<S> sourceType();
    class_1299<P> petType();

    default void copyCommon(S src, P pet, class_1657 owner){
        pet.method_5808(src.method_23317(), src.method_23318(), src.method_23321(), src.method_36454(), src.method_36455());
        pet.method_5636(src.method_73188());
        pet.method_5847(src.method_5791());
        pet.method_6033(Math.min(src.method_6032(), pet.method_6063()));

        if (src.method_16914()){
            pet.method_5665(src.method_5797());
            pet.method_5880(src.method_5807());
        }

        pet.getDelegate().setPetOwnerUuid(owner.method_5667());
        pet.setPetSitting(false);
    }

    void copySpecific(S src, P pet);
}
