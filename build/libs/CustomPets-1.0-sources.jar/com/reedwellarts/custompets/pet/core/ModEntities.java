package com.reedwellarts.custompets.pet.core;

import com.reedwellarts.custompets.CustomPets;
import com.reedwellarts.custompets.pet.entities.PetFoxEntity;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;

public class ModEntities {

    public static final class_1299<PetFoxEntity> PET_FOX_ENTITY = class_2378.method_10230(
            class_7923.field_41177,
            class_2960.method_60655(CustomPets.MOD_ID, "pet_fox_entity"),
            class_1299.class_1300.method_5903(PetFoxEntity::new, class_1311.field_6294)
                    .method_17687(0.6f, 0.85f)
                    .method_5905(class_5321.method_29179(class_7923.field_41177.method_46765(), class_2960.method_60655(CustomPets.MOD_ID, "pet_fox_entity")))
    );

    public static void registerModEntities() {}
}
