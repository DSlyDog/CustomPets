package com.reedwellarts.custompets.pet.core.interfaces;

import com.reedwellarts.custompets.pet.data.PetDelegate;
import org.jspecify.annotations.Nullable;

import java.util.UUID;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_3218;

public interface OwnablePet {

    class_1309 asLiving();
    PetDelegate getDelegate();

    boolean isPetSitting();
    void setPetSitting(boolean sitting);

    boolean isFlyable();
    void setFlyable(boolean flyable);

    boolean isFlightDescending();
    void setFlightDescending(boolean isDescending);

    class_1299 getBaseType();

    void unsetPetRemoved();

    void applySavedVariant(@Nullable String variantId);

    default @Nullable class_1657 getOwnerPlayer() {
        class_1309 self = asLiving();
        if (!(self.method_73183() instanceof class_3218 server)) return null;

        UUID uuid = getDelegate().getPetOwnerUuid();
        return uuid == null ? null : server.method_18470(uuid);
    }
}
