package com.reedwellarts.custompets.pet.core.interfaces;

import com.reedwellarts.custompets.pet.core.enums.SkillCategory;
import com.reedwellarts.custompets.pet.data.PetData;
import org.jetbrains.annotations.NotNull;

public interface Skill {

    void apply(PetData data);

    @NotNull int getUnlockLevel();
    @NotNull SkillCategory getSkillCategory();
}
