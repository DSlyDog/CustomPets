package com.reedwellarts.custompets.pet.goals;

import com.reedwellarts.custompets.pet.core.interfaces.OwnablePet;
import org.jetbrains.annotations.Nullable;

import java.util.EnumSet;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1352;
import net.minecraft.class_1657;

public class PetFollowOwnerTargetGoal<T extends class_1308 & OwnablePet> extends class_1352 {

    private @Nullable class_1309 ownerTarget;
    private T pet;

    public PetFollowOwnerTargetGoal(T pet){
        this.pet = pet;
        this.method_6265(EnumSet.of(class_4134.field_18408));
    }

    @Override
    public boolean method_6264() {
        class_1657 owner = pet.getOwnerPlayer();
        if (owner == null) return false;
        ownerTarget = owner.method_6052();
        return ownerTarget != null;
    }

    @Override
    public void method_6269() {
        pet.method_5980(ownerTarget);
    }

    @Override
    public boolean method_6266() {
        return pet.method_5968() != null && pet.method_5968().method_5805();
    }
}
