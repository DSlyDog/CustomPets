package com.reedwellarts.custompets.pet.goals;

import com.reedwellarts.custompets.pet.core.interfaces.OwnablePet;
import java.util.EnumSet;
import net.minecraft.class_1308;
import net.minecraft.class_1352;
import net.minecraft.class_1657;
import net.minecraft.class_2183;

public class PetFollowOwnerGoal<T extends class_1308 & OwnablePet> extends class_1352 {
    private final T pet;
    private final double speed;
    private final float startDistance;
    private final float stopDistance;
    private class_1657 owner;

    public PetFollowOwnerGoal(T pet, double speed, float startDistance, float stopDistance){
        this.pet = pet;
        this.speed = speed;
        this.startDistance = startDistance;
        this.stopDistance = stopDistance;
        this.method_6265(EnumSet.of(class_4134.field_18405, class_4134.field_18406));
    }

    @Override
    public boolean method_6264() {
        if (pet.isPetSitting()) return false;

        owner = pet.getOwnerPlayer();

        if (owner == null || owner.method_7325()) return false;

        return pet.method_5858(owner) > (startDistance * startDistance);
    }

    @Override
    public boolean method_6266() {
        if (pet.isPetSitting()) return false;

        return owner != null && owner.method_5805()
                && pet.method_5858(owner) > (stopDistance * stopDistance);
    }

    @Override
    public boolean method_38846() {
        return true;
    }

    @Override
    public void method_6268() {
        if (owner == null) return;

        pet.method_5702(class_2183.class_2184.field_9851, owner.method_33571());

        if (pet.field_6012 % 10 == 0){
            pet.method_5942().method_6335(owner, speed);
        }
    }

    @Override
    public void method_6270() {
        owner = null;
        pet.method_5942().method_6340();
    }
}
