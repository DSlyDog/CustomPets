package com.reedwellarts.custompets.pet.goals;

import com.reedwellarts.custompets.pet.core.interfaces.OwnablePet;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1400;
import net.minecraft.class_1657;
import net.minecraft.class_3417;
import net.minecraft.class_4019;
import net.minecraft.class_4051;
import org.jspecify.annotations.Nullable;

public class PetDefendOwnerGoal<T extends class_1308 & OwnablePet> extends class_1400<class_1309> {
    private @Nullable class_1309 offender;
    private T pet;
    private int lastAttackedTime;

    public PetDefendOwnerGoal(T pet, final Class<class_1309> targetEntityClass, final boolean checkVisibility, final @Nullable boolean checkCanNavigate, final class_4051.class_10254 targetPredicate) {
        super(pet, targetEntityClass, 10, checkVisibility, checkCanNavigate, targetPredicate);
        this.pet = pet;
    }

    public boolean method_6264() {
        if (this.field_6641 > 0 && this.field_6660.method_59922().method_43048(this.field_6641) != 0) {
            return false;
        } else {
            class_1657 owner = pet.getOwnerPlayer();
            if (owner != null) {
                this.offender = owner.method_6065();
                int i = owner.method_6117();
                return i != this.lastAttackedTime && this.method_6328(this.offender, this.field_6642);
            }
            return false;
        }
    }

    public void method_6269() {
        this.method_24632(this.offender);
        this.field_6644 = this.offender;
        if (pet.getOwnerPlayer() != null) {
            this.lastAttackedTime = pet.getOwnerPlayer().method_6117();
        }

        if (pet instanceof class_4019) {
            pet.method_5783(class_3417.field_18055, 1.0F, 1.0F);
        }

        pet.method_19540(true);

        super.method_6269();
    }
}
