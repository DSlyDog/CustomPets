package com.reedwellarts.custompets.pet.entities;

import com.reedwellarts.custompets.CustomPets;
import com.reedwellarts.custompets.pet.core.interfaces.OwnablePet;
import com.reedwellarts.custompets.event_handlers.state.PetTrackingState;
import com.reedwellarts.custompets.pet.goals.PetDefendOwnerGoal;
import com.reedwellarts.custompets.pet.goals.PetFollowOwnerGoal;
import com.reedwellarts.custompets.pet.data.PetDelegate;
import com.reedwellarts.custompets.pet.goals.PetFollowOwnerTargetGoal;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1277;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1347;
import net.minecraft.class_1353;
import net.minecraft.class_1359;
import net.minecraft.class_1361;
import net.minecraft.class_1371;
import net.minecraft.class_1394;
import net.minecraft.class_1657;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_4018;
import net.minecraft.class_4019;
import net.minecraft.class_6067;
import net.minecraft.class_6868;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.entity.passive.*;
import org.jspecify.annotations.Nullable;

import java.lang.reflect.Method;
import java.util.function.Predicate;

public class PetFoxEntity extends class_4019 implements OwnablePet, class_6067 {

    private static final class_2940<Boolean> SITTING =
            class_2945.method_12791(PetFoxEntity.class, class_2943.field_13323);
    private static final class_2940<Boolean> FLYABLE =
            class_2945.method_12791(PetFoxEntity.class, class_2943.field_13323);
    private static final class_2940<Boolean> DESCENDING =
            class_2945.method_12791(PetFoxEntity.class, class_2943.field_13323);
    private static final Predicate<class_1297> JUST_ATTACKED_SOMETHING_FILTER;
    private static final Method SET_VARIANT_METHOD;

    static {
        JUST_ATTACKED_SOMETHING_FILTER = (entity) -> {
            if (!(entity instanceof class_1309 livingEntity)) {
                return false;
            } else {
                return livingEntity.method_6052() != null && livingEntity.method_6083() < livingEntity.field_6012 + 600;
            }
        };

        Method m = null;
        try {
            m = class_4019.class.getDeclaredMethod("setVariant", class_4019.class_4039.class);
            m.setAccessible(true);
        }catch (NoSuchMethodException e){
            CustomPets.LOGGER.error("Could not find FoxEntity#setVariant(FoxEntity.Variant)", e);
        }
        SET_VARIANT_METHOD = m;
    }

    private final PetDelegate<PetFoxEntity> delegate = new PetDelegate<>(this, class_1802.field_16998);
    private class_1277 inventory = new class_1277(9 * delegate.getDataManager().getData().inventoryRows);

    public PetFoxEntity(class_1299<? extends class_4019> entityType, class_1937 world) {
        super(entityType, world);
        delegate.setPetName(method_5477().getString());
    }

    @Override
    public PetDelegate getDelegate(){
        return delegate;
    }

    @Override
    protected void method_5693(class_2945.class_9222 builder) {
        super.method_5693(builder);
        builder.method_56912(SITTING, false);
        builder.method_56912(FLYABLE, false);
        builder.method_56912(DESCENDING, false);
    }

    @Override
    protected void method_5959() {
        super.method_5959();
        this.field_6201.method_35113(goal -> true);

        this.field_6201.method_6277(0, new class_1347(this));
        this.field_6201.method_6277(0, new class_6868(this, this.method_73183()));
        this.field_6201.method_6277(6, new class_4033());
        this.field_6201.method_6277(7, new class_1371(this));
        this.field_6201.method_6277(8, new class_1353(this, (double)1.25F));
        this.field_6201.method_6277(9, new class_4018(this, 200));
        this.field_6201.method_6277(10, new class_4025((double)1.2F, 12, 1));
        this.field_6201.method_6277(10, new class_1359(this, 0.4F));
        this.field_6201.method_6277(11, new class_1394(this, (double)1.0F));
        this.field_6201.method_6277(12, new class_1361(this, class_1657.class, 24.0F));

        this.field_6201.method_6277(1, new PetFollowOwnerGoal<>(this, 1.1D, 8.0F, 3.0F));
        this.field_6201.method_6277(2, new PetDefendOwnerGoal<>(
                this,
                class_1309.class,
                false,
                false,
                (entity, world) ->
                        JUST_ATTACKED_SOMETHING_FILTER.test(entity) && !delegate.canTrust(entity))
        );
        this.field_6201.method_6277(2, new PetFollowOwnerTargetGoal<>(this));
    }

    @Override
    public class_1299 getBaseType() {
        return class_1299.field_17943;
    }

    @Override
    public boolean isPetSitting() {
        return this.field_6011.method_12789(SITTING);
    }

    @Override
    public void setPetSitting(boolean sitting) {
        this.field_6011.method_12778(SITTING, sitting);
        this.method_18294(sitting);
    }

    @Override
    public boolean isFlyable() {
        return this.field_6011.method_12789(FLYABLE);
    }

    @Override
    public void setFlyable(boolean flyable) {
        this.field_6011.method_12778(FLYABLE, flyable);
    }

    @Override
    public boolean isFlightDescending() {
        return this.field_6011.method_12789(DESCENDING);
    }


    @Override
    public void setFlightDescending(boolean isDescending) {
        this.field_6011.method_12778(DESCENDING, isDescending);
    }

    @Override
    public class_4019 asLiving() {
        return this;
    }

    @Override
    protected boolean method_5818(class_1297 passenger){
        return passenger instanceof class_1657 && this.method_5685().isEmpty();
    }

    @Override
    public class_1309 method_5642(){
        class_1297 first = this.method_31483();
        return first instanceof class_1309 living ? living : null;
    }

    @Override
    public void method_6091(class_243 movementInput) {
        class_243 result = delegate.travel(this, movementInput);
        this.method_5710(this.method_36454(), this.method_36455());
        super.method_6091(result);
    }

    @Override
    public boolean method_5747(double fallDistance, float damagePerDistance, class_1282 damageSource) {
        if (delegate.onFall(this)) return false;
        return super.method_5747(fallDistance, damagePerDistance, damageSource);
    }

    @Override
    public void method_5773(){
        super.method_5773();
        delegate.tick(this);
    }

    @Override
    public class_1269 method_5992(class_1657 player, class_1268 hand) {
        class_1277 inv = delegate.updateInventory(this);
        CustomPets.LOGGER.info("inv != null: {}", inv != null);
        inventory = inv != null ? inv : inventory;
        class_1269 result = delegate.interactMob(this, player, hand);
        return result != null ? result : super.method_5992(player, hand);
    }

    @Override
    public boolean method_64397(class_3218 serverWorld, class_1282 damageSource, float amount) {
        if (damageSource.method_5529() instanceof class_3222 player){
            if (player.method_5667().equals(delegate.getPetOwnerUuid())) return false;
        }

        boolean damaged = super.method_64397(serverWorld, damageSource, amount);
        if (damaged) {
            delegate.setPetHealth((int) this.method_6032());
        }
        return damaged;
    }

    @Override
    public boolean method_6121(class_3218 world, class_1297 target) {
        boolean result = super.method_6121(world, target);
        delegate.tryAttack(this, result, target);
        return result;
    }



    @Override
    public void method_6078(class_1282 damageSource) {
        PetTrackingState.Entry entry = delegate.onDeath(this, damageSource);
        if (entry != null) entry.petVariant = this.method_47845().method_15434();
        super.method_6078(damageSource);
    }

    @Override
    public void applySavedVariant(@Nullable String variantId){
        if (variantId == null || variantId.isBlank()) return;
        if (SET_VARIANT_METHOD == null) return;

        try{
            class_4019.class_4039 variant = class_4019.class_4039.valueOf(variantId);
            SET_VARIANT_METHOD.invoke(this, variant);
        }catch(Exception e){
            CustomPets.LOGGER.warn("Failed to apply fox variant '{}' to pet fox {}", variantId, this.method_5667(), e);
        }
    }

    @Override
    public void unsetPetRemoved(){
        super.method_31482();
    }

    @Override
    public void method_5665(@Nullable class_2561 name) {
        super.method_5665(name);
        delegate.setPetName(name == null ? method_5477().getString() : name.getString());
    }

    @Override
    public class_1277 method_35199() {
        return inventory;
    }

    @Override
    protected void method_5652(class_11372 view) {
        super.method_5652(view);
        delegate.writeCustomData(this, view);
    }

    @Override
    protected void method_5749(class_11368 view) {
        super.method_5749(view);
        delegate.readCustomData(this, view);
    }
}
