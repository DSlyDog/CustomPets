package com.reedwellarts.custompets.pet.converters;

import com.reedwellarts.custompets.pet.core.ModEntities;
import com.reedwellarts.custompets.pet.core.interfaces.PetConverter;
import com.reedwellarts.custompets.pet.entities.PetFoxEntity;
import net.minecraft.class_1299;
import net.minecraft.class_4019;

public class FoxPetConverter implements PetConverter<class_4019, PetFoxEntity> {


    @Override
    public class_1299<class_4019> sourceType() {
        return class_1299.field_17943;
    }

    @Override
    public class_1299<PetFoxEntity> petType() {
        return ModEntities.PET_FOX_ENTITY;
    }

    @Override
    public void copySpecific(class_4019 src, PetFoxEntity pet) {
        pet.method_5614(src.method_5618());
        pet.applySavedVariant(src.method_47845().method_15434().toUpperCase());
    }
}
