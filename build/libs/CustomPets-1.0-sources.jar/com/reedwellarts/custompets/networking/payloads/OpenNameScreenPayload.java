package com.reedwellarts.custompets.networking.payloads;

import com.reedwellarts.custompets.CustomPets;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record OpenNameScreenPayload(String petUuid) implements class_8710 {

    public static final class_9154<OpenNameScreenPayload> ID =
            new class_9154<>(class_2960.method_60655(CustomPets.MOD_ID, "open_name_screen"));

    public static final class_9139<class_9129, OpenNameScreenPayload> CODEC =
            class_9139.method_56434(
                    class_9135.field_48554, OpenNameScreenPayload::petUuid,
                    OpenNameScreenPayload::new
            );

    @Override
    public class_9154<? extends class_8710> method_56479(){
        return ID;
    }
}
