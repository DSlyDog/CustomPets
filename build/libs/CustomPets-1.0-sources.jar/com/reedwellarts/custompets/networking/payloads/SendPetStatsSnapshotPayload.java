package com.reedwellarts.custompets.networking.payloads;

import com.reedwellarts.custompets.CustomPets;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record SendPetStatsSnapshotPayload(
        List<PetSnapshot> pets,
        int maxActive
) implements class_8710 {

    public record PetSnapshot(
            String petUuid,
            String petType,
            String name,
            int health,
            int maxHealth,
            int level,
            int xp,
            int xpToNextLevel,
            List<String> unlockedSkills,
            List<String> activeSkills,
            boolean active
    ){
        public static final class_9139<class_9129, PetSnapshot> CODEC = class_9139.method_71952(
                class_9135.field_48554, PetSnapshot::petUuid,
                class_9135.field_48554, PetSnapshot::petType,
                class_9135.field_48554, PetSnapshot::name,
                class_9135.field_49675, PetSnapshot::health,
                class_9135.field_49675, PetSnapshot::maxHealth,
                class_9135.field_49675, PetSnapshot::level,
                class_9135.field_49675, PetSnapshot::xp,
                class_9135.field_49675, PetSnapshot::xpToNextLevel,
                class_9135.method_56376(ArrayList::new, class_9135.field_48554), PetSnapshot::unlockedSkills,
                class_9135.method_56376(ArrayList::new, class_9135.field_48554), PetSnapshot::activeSkills,
                class_9135.field_48547, PetSnapshot::active,
                PetSnapshot::new
        );
    }

    public static final class_9154<SendPetStatsSnapshotPayload> ID =
            new class_9154<>(class_2960.method_60655(CustomPets.MOD_ID, "send_pet_stats"));

    public static final class_9139<class_9129, SendPetStatsSnapshotPayload> CODEC = class_9139.method_56435(
            class_9135.method_56376(ArrayList::new, PetSnapshot.CODEC), SendPetStatsSnapshotPayload::pets,
            class_9135.field_49675, SendPetStatsSnapshotPayload::maxActive,
            SendPetStatsSnapshotPayload::new
    );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
