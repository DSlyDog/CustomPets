package com.reedwellarts.custompets.networking.payloads;

import com.reedwellarts.custompets.CustomPets;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record SetPetActiveSkillsPayload(
        String petUuid,
        List<String> activeSkills
) implements class_8710 {

    public static final class_9154<SetPetActiveSkillsPayload> ID =
            new class_9154<>(class_2960.method_60655(CustomPets.MOD_ID, "set_pet_active_skills"));

    public static final class_9139<class_9129, SetPetActiveSkillsPayload> CODEC =
            class_9139.method_56435(
              class_9135.field_48554, SetPetActiveSkillsPayload::petUuid,
              class_9135.method_56376(ArrayList::new, class_9135.field_48554), SetPetActiveSkillsPayload::activeSkills,
              SetPetActiveSkillsPayload::new
            );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
