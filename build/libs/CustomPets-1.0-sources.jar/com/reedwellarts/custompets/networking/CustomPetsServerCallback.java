package com.reedwellarts.custompets.networking;

import com.reedwellarts.custompets.event_handlers.state.PetTrackingState;
import com.reedwellarts.custompets.networking.payloads.SetActivePetsPayload;
import com.reedwellarts.custompets.pet.core.interfaces.OwnablePet;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import java.util.List;
import java.util.UUID;

public class CustomPetsServerCallback {

    public static void namePet(String name, String petUuid, ServerPlayNetworking.Context context){
        class_3218 world = context.player().method_51469();
        class_1297 entity = world.method_66347(UUID.fromString(petUuid));

        if (entity != null){
            entity.method_5665(class_2561.method_43470(name));
            entity.method_5880(true);
        }
    }

    public static void setPetActiveSkills(String petUuid, List<String> requestedActive, ServerPlayNetworking.Context context){
        class_3218 world = context.player().method_51469();
        class_1297 entity = world.method_66347(UUID.fromString(petUuid));
        if (!(entity instanceof OwnablePet ownable) || !(entity instanceof class_1309 living)) return;

        var delegate = ownable.getDelegate();
        if (delegate.getPetOwnerUuid() == null || !delegate.getPetOwnerUuid().equals(context.player().method_5667())) return;

        var manager = delegate.getDataManager();
        var state = manager.getSkillState();

        for (class_2960 id : state.getActive()){
            manager.deactivateSkill(id);
        }

        for (String raw : requestedActive){
            class_2960 id = class_2960.method_12829(raw);
            if (id == null) continue;
            manager.activateSkill(id);
        }

        ownable.setFlyable(manager.isFlyable());
    }

    public static void doDismountPlayer(String petUuid, ServerPlayNetworking.Context context) {
        class_1297 entity = context.player().method_51469().method_66347(UUID.fromString(petUuid));

        if (entity instanceof OwnablePet pet){
            pet.getDelegate().dismountPlayer((class_1308) pet);
        }
    }

    public static void updateActivePets(SetActivePetsPayload payload, ServerPlayNetworking.Context context){
        PetTrackingState state = PetTrackingState.get(context.player().method_51469());
        state.updateActivePets(context.player().method_5667(), payload.petUuids(), context.player().method_51469());
    }
}
