package com.reedwellarts.custompets.client;

import com.reedwellarts.custompets.CustomPets;
import com.reedwellarts.custompets.client.networking.CustomPetsClientNetworking;
import com.reedwellarts.custompets.pet.core.ModEntities;
import com.reedwellarts.custompets.pet.core.interfaces.OwnablePet;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_1297;
import net.minecraft.class_4042;
import net.minecraft.class_5619;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CustomPetsClient implements ClientModInitializer {

    public static final String MOD_ID = "custompets";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitializeClient() {
        class_5619.method_32173(ModEntities.PET_FOX_ENTITY, class_4042::new);

        CustomPetsClientNetworking.register();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.field_1724 != null && client.field_1724.method_5854() instanceof OwnablePet pet && pet.isFlyable()){
                if (client.field_1690.field_1832.method_1434()){
                    if (((class_1297) pet).method_24828()){
                        LOGGER.info("Client sees dismount");
                        client.field_1724.method_29239();
                        pet.setFlightDescending(false);
                        ((class_1297) pet).method_5772();
                        CustomPetsClientNetworking.sendDismountNotice(((class_1297) pet).method_5845());
                    }else {
                        pet.setFlightDescending(true);
                    }
                }else{
                    pet.setFlightDescending(false);
                }
            }
        });
    }
}
