package com.reedwellarts.custompets.client.screen;

import com.reedwellarts.custompets.client.networking.CustomPetsClientNetworking;
import net.minecraft.class_11908;
import net.minecraft.class_2561;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_7842;
import org.lwjgl.glfw.GLFW;

public class PetNameScreen extends class_437 {

    private class_7842 title;
    private class_342 nameField;
    private final String petUuid;

    public PetNameScreen(String petUuid){
        super(class_2561.method_43470("Name pet"));
        this.petUuid = petUuid;
    }

    @Override
    protected void method_25426() {
        title = new class_7842(field_22789 / 2 - (field_22793.method_30880(method_25440().method_30937()) / 2), field_22790 / 2 - 60, field_22793.method_30880(method_25440().method_30937()), 20, method_25440(), field_22793);
        method_37063(title);

        nameField = new class_342(field_22793, field_22789 / 2 - 100, field_22790 / 2 - 20, 200 , 20, class_2561.method_43470("Portal name"));
        nameField.method_1880(32);
        nameField.method_25365(true);
        method_25395(nameField);
        method_37063(nameField);

        method_37063(class_4185.method_46430(class_2561.method_43470("Confirm"), button -> confirm())
                .method_46434(field_22789 / 2 - 102, field_22790 / 2 + 8, 98, 20)
                .method_46431());

        method_37063(class_4185.method_46430(class_2561.method_43470("Cancel"), button -> method_25419())
                .method_46434(field_22789 / 2 + 4, field_22790 / 2 + 8, 98, 20)
                .method_46431());
    }

    @Override
    public boolean method_25404(class_11908 keyInput){
        if (keyInput.method_74228() == GLFW.GLFW_KEY_ENTER || keyInput.method_74228() == GLFW.GLFW_KEY_KP_ENTER){
            confirm();
            return true;
        }
        return super.method_25404(keyInput);
    }

    @Override
    public boolean method_25421(){
        return false;
    }

    private void confirm(){
        String name = nameField.method_1882().trim();
        name = name.replace("&", "§");

        if (name.isEmpty()) return;

        CustomPetsClientNetworking.setEntityName(name, petUuid);
        method_25419();
    }
}
