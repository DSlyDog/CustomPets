package com.reedwellarts.custompets.client.screen;

import com.reedwellarts.custompets.client.networking.CustomPetsClientNetworking;
import com.reedwellarts.custompets.client.networking.snapshot.PetStatsSnapshot;
import java.util.*;
import net.minecraft.class_11909;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1826;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_7923;

public class PetRosterScreen extends class_437 {

    private static final int WINDOW_W = 320;
    private static final int WINDOW_H = 180;
    private static final int SLOT = 18;
    private static final int PAD = 8;
    private static final int STATS_H = 58;
    private static final int TAMED_COLS = 8;
    private static final int TAMED_ROWS = 3;
    private static final int ACTIVE_COLS = 2;
    private static final int ACTIVE_ROWS = 2;

    private final List<PetStatsSnapshot> pets;
    private final Map<Integer, String> activeSlots = new HashMap<>();

    private final int maxActive;

    private int left;
    private int top;

    private String selectedPetUuid;
    private String draggingPetUuid;
    private int draggingFromActiveIndex = -1;


    public PetRosterScreen(List<PetStatsSnapshot> pets, int maxActive) {
        super(class_2561.method_43470("Pet Roster"));
        this.pets = new ArrayList<>(pets);
        this.maxActive = Math.clamp(maxActive, 1, ACTIVE_COLS * ACTIVE_ROWS);

        List<String> initiallyActive = this.pets.stream()
                .filter(PetStatsSnapshot::active)
                .map(PetStatsSnapshot::petUuid)
                .sorted()
                .toList();

        for (int i = 0; i < Math.min(maxActive, initiallyActive.size()); i++){
            activeSlots.put(i, initiallyActive.get(i));
        }

        if (!this.pets.isEmpty()){
            this.selectedPetUuid = this.pets.getFirst().petUuid();
        }
    }

    @Override
    protected void method_25426(){
        this.left = (this.field_22789 - WINDOW_W) / 2;
        this.top = (this.field_22790 - WINDOW_H) / 2;

        method_37063(class_4185.method_46430(class_2561.method_43470("Close"), b -> method_25419())
                .method_46434(left + WINDOW_W - 68, top + WINDOW_H + 6, 60, 20)
                .method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470("Confirm"), b -> confirm())
                .method_46434(left + WINDOW_W - 136, top + WINDOW_H + 6, 60, 20)
                .method_46431());
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float deltaTicks) {
        context.method_25294(left, top, left + WINDOW_W, top + WINDOW_H, 0xCC1E1E1E);
        drawBorder(context, left, top, WINDOW_W, WINDOW_H, 0xFFFFFFFF);

        drawStatsPanel(context);
        drawTamedGrid(context, mouseX, mouseY);
        drawActiveGrid(context, mouseX, mouseY);

        if (draggingPetUuid != null){
            PetStatsSnapshot snapshot = findByUuid(draggingPetUuid);
            if (snapshot != null){
                context.method_25294(mouseX - 9, mouseY - 9, mouseX + 9, mouseY + 9, 0xD0000000);
                drawBorder(context, mouseX - 9, mouseY - 9, 18, 18, 0xFFFFFFFF);
                drawPetEgg(context, snapshot, mouseX - 8, mouseY - 8);
            }
        }

        super.method_25394(context, mouseX, mouseY, deltaTicks);
    }

    private void drawBorder(class_332 context, int x, int y, int w, int h, int color){
        context.method_25294(x, y, x + w, y + 1, color);
        context.method_25294(x, y + h - 1, x + w, y + h, color);
        context.method_25294(x, y, x + 1, y + h, color);
        context.method_25294(x + w - 1, y, x + w, y + h, color);
    }

    private void drawStatsPanel(class_332 context){
        int x = left + PAD;
        int y = top + 18;
        int w = WINDOW_W - PAD * 2;

        context.method_25294(x, y, x + w, y + STATS_H, 0x88252525);
        drawBorder(context, x, y, w, STATS_H, 0xFF555555);

        PetStatsSnapshot selected = selectedPetUuid == null ? null : findByUuid(selectedPetUuid);
        if (selected == null){
            context.method_51439(field_22793, class_2561.method_43470("Select a pet"), x + 6, y + 6, 0xFFAAAAAA, false);
            return;
        }

        context.method_51439(field_22793,
                class_2561.method_43470(selected.name() + " Lv." + selected.level()),
                x + 6, y + 6, 0xFFFFFFFF, false);

        int barX = x + 6;
        int barW = w - 12;

        drawBar(context, barX, y + 26, barW, 8,
                selected.health(), Math.max(1, selected.maxHealth()),
                0xFF2A2A2A, 0xFFD94A4A,
                "HP " + selected.health() + "/" + selected.maxHealth());

        drawBar(context, barX, y + 46, barW, 8,
                selected.xp(), Math.max(1, selected.xpToNextLevel()),
                0xFF2A2A2A, 0xFF3C9C28,
                "XP " + selected.xp() + "/" + selected.xpToNextLevel());
    }

    private void drawTamedGrid(class_332 context, int mouseX, int mouseY){
        int x = left + PAD;
        int y = top + 24 + STATS_H + PAD;

        context.method_51439(field_22793, class_2561.method_43470("Tamed"), x, y - 10, 0xFFFFFFFF, false);

        List<PetStatsSnapshot> sorted = pets.stream()
                .sorted(Comparator.comparing(PetStatsSnapshot::name))
                .toList();

        for (int i = 0; i < TAMED_COLS * TAMED_ROWS; i++){
            int sx = x + (i % TAMED_COLS) * (SLOT + 2);
            int sy = y + (i / TAMED_COLS) * (SLOT + 2);
            drawSlot(context, sx, sy, false);

            if (i >= sorted.size()) continue;

            PetStatsSnapshot snapshot = sorted.get(i);
            drawPetEgg(context, snapshot, sx + 1, sy + 1);

            if (isInside(mouseX, mouseY, sx, sy, SLOT, SLOT)){
                selectedPetUuid = snapshot.petUuid();
            }
        }
    }

    private void drawActiveGrid(class_332 context, int mouseX, int mouseY){
        int x = left + WINDOW_W - PAD - (ACTIVE_COLS * (SLOT + 2));
        int y = top + 24 + STATS_H + PAD;

        context.method_51439(field_22793, class_2561.method_43470("Active"), x, y - 10, 0xFFFFFFFF, false);

        for (int i=0; i < ACTIVE_COLS * ACTIVE_ROWS; i++){
            int sx = x + (i % ACTIVE_COLS) * (SLOT + 2);
            int sy = y + (i / ACTIVE_COLS) * (SLOT + 2);
            drawSlot(context, sx, sy, i >= maxActive);

            if (i < maxActive){
                String petId = activeSlots.get(i);
                if (petId != null){
                    PetStatsSnapshot snapshot = findByUuid(petId);
                    if (snapshot != null){
                        drawPetEgg(context, snapshot, sx + 1, sy + 1);
                        if (isInside(mouseX, mouseY, sx, sy, SLOT, SLOT)){
                            selectedPetUuid = snapshot.petUuid();
                        }
                    }
                }
            }
        }
    }

    private void drawSlot(class_332 context, int x, int y, boolean disabled){
        int fill = disabled ? 0x55333333 : 0xAA1A1A1A;
        int border = disabled ? 0xFF444444 : 0xFF888888;
        context.method_25294(x, y, x + SLOT, y + SLOT, fill);
        drawBorder(context, x, y, SLOT, SLOT, border);
    }

    private void drawBar(class_332 context, int x, int y, int w, int h,
                         int value, int max, int bg, int fg, String label){
        context.method_25294(x, y, x + w, y + h, bg);
        int fill = (int) ((Math.clamp(value, 0, max) / (double) max) * w);
        context.method_25294(x, y, x + fill, y + h, fg);
        drawBorder(context, x, y, w, h,0xFF000000);
        context.method_51439(field_22793, class_2561.method_43470(label), x + 2, y - 9, 0xFFDDDDDD, false);
    }

    private void drawPetEgg(class_332 context, PetStatsSnapshot snapshot, int x, int y){
        class_1799 stack = getSpawnEggStack(snapshot.petType());
        context.method_51427(stack, x, y);
    }

    @Override
    public boolean method_25402(class_11909 click, boolean doubled) {
        if (click.method_74245() != 0) return super.method_25402(click, doubled);

        String tamedHit = getTamedHit(click.comp_4798(), click.comp_4799());
        if (tamedHit != null){
            draggingPetUuid = tamedHit;
            draggingFromActiveIndex = indexOfActiveSlot(tamedHit);
            selectedPetUuid = tamedHit;
            return true;
        }

        int activeIndex = getActiveSlotIndex(click.comp_4798(), click.comp_4799());
        if (activeIndex >= 0 && activeIndex < maxActive){
            String id = activeSlots.get(activeIndex);
            if (id != null) {
                draggingPetUuid = id;
                draggingFromActiveIndex = activeIndex;
                selectedPetUuid = id;
                return true;
            }
        }

        return super.method_25402(click, doubled);
    }

    @Override
    public boolean method_25403(class_11909 click, double offsetX, double offsetY) {
        if (draggingPetUuid != null) return true;
        return super.method_25403(click, offsetX, offsetY);
    }

    @Override
    public boolean method_25406(class_11909 click) {
        if (click.method_74245() != 0 || draggingPetUuid == null){
            return super.method_25406(click);
        }

        int dropIndex = getActiveSlotIndex(click.comp_4798(), click.comp_4799());

        removePetFromActiveSlots(draggingPetUuid);

        if (dropIndex >= 0 && dropIndex < maxActive){
            activeSlots.put(dropIndex, draggingPetUuid);
        }else if (draggingFromActiveIndex >= 0){
            activeSlots.remove(draggingFromActiveIndex);
        }

        draggingPetUuid = null;
        draggingFromActiveIndex = -1;
        return true;
    }

    private String getTamedHit(double mouseX, double mouseY){
        int x = left + PAD;
        int y = top + 24 + STATS_H + PAD;

        List<PetStatsSnapshot> sorted = pets.stream()
                .sorted(Comparator.comparing(PetStatsSnapshot::name))
                .toList();

        for (int i = 0; i < sorted.size(); i++){
            int sx = x + (i % TAMED_COLS) * (SLOT + 2);
            int sy = y + (i / TAMED_COLS) * (SLOT + 2);
            if (isInside(mouseX, mouseY, sx, sy, SLOT, SLOT)){
                return sorted.get(i).petUuid();
            }
        }
        return null;
    }

    private int getActiveSlotIndex(double mouseX, double mouseY){
        int x = left + WINDOW_W - PAD - (ACTIVE_COLS * (SLOT + 2));
        int y = top + 24 + STATS_H + PAD;

        for (int i = 0; i < ACTIVE_COLS * ACTIVE_ROWS; i++){
            int sx = x + (i % ACTIVE_COLS) * (SLOT + 2);
            int sy = y + (i / ACTIVE_COLS) * (SLOT + 2);
            if (isInside(mouseX, mouseY, sx, sy, SLOT, SLOT)) return i;
        }

        return - 1;
    }

    private int indexOfActiveSlot(String petUuid){
        for (int i = 0; i < maxActive; i++){
            String id = activeSlots.get(i);
            if (petUuid.equals(id)) return i;
        }
        return -1;
    }

    private void removePetFromActiveSlots(String petUuid){
        Integer keyToRemove = null;
        for (Map.Entry<Integer, String> entry : activeSlots.entrySet()){
            if (petUuid.equals(entry.getValue())){
                keyToRemove = entry.getKey();
                break;
            }
        }

        if (keyToRemove != null) activeSlots.remove(keyToRemove);
    }

    private boolean isInside(double mouseX, double mouseY, int x, int y, int w, int h){
        return mouseX >= x && mouseX < x + w && mouseY >= y && mouseY < y + h;
    }

    private PetStatsSnapshot findByUuid(String uuid){
        for (PetStatsSnapshot snapshot : pets){
            if (snapshot.petUuid().equals(uuid)) return snapshot;
        }
        return null;
    }

    private class_1799 getSpawnEggStack(String petType){
        class_2960 entityId = class_2960.method_12829(petType);
        if (entityId == null){
            return new class_1799(class_1802.field_8077);
        }

        class_2960 eggId = class_2960.method_60655(entityId.method_12836(), entityId.method_12832() + "_spawn_egg");
        class_1792 item = class_7923.field_41178.method_63535(eggId);

        if (item instanceof class_1826){
            return new class_1799(item);
        }

        return new class_1799(class_1802.field_8077);
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    private void confirm(){
        List<String> petUuids = new ArrayList<>();

        for (Map.Entry<Integer, String> entry : activeSlots.entrySet()){
            petUuids.add(entry.getValue());
        }

        CustomPetsClientNetworking.setActivePets(petUuids);
    }
}
