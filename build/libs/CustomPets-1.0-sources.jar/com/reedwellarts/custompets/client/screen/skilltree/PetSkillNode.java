package com.reedwellarts.custompets.client.screen.skilltree;

import java.util.Set;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;

public record PetSkillNode(
    class_2960 id,
    class_1799 item,
    class_2561 title,
    class_2561 description,
    int x,
    int y,
    Set<class_2960> parents,
    boolean unlocked,
    int unlockLevel
) { }
