package com.reedwellarts.custompets.client.screen.skilltree;

import com.reedwellarts.custompets.pet.skill.SkillRegistry;
import com.reedwellarts.custompets.pet.skill.skills.*;
import java.util.List;
import java.util.Set;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;

public final class SkillTreeDefinition {

    private static final int NODE_OFFSET = 50;

    public static final List<PetSkillNode> ALL = List.of(
            new PetSkillNode(
                    SkillRegistry.MOUNT,
                    new class_1799(class_1802.field_8175),
                    class_2561.method_43470("§bMount"),
                    class_2561.method_43470("Make your pet a rideable mount"),
                    0, 0,
                    Set.of(),
                    false,
                    new MountSkill().getUnlockLevel()
            ),
            new PetSkillNode(
                    SkillRegistry.FLYING_MOUNT,
                    new class_1799(class_1802.field_8833),
                    class_2561.method_43470("§bFlying Mount"),
                    class_2561.method_43470("Make your pet a flyable mount"),
                    NODE_OFFSET, 0,
                    Set.of(SkillRegistry.MOUNT),
                    false,
                    new FlyingMountSkill().getUnlockLevel()
            ),
            new PetSkillNode(
                    SkillRegistry.DAMAGE_DEALER,
                    new class_1799(class_1802.field_8802),
                    class_2561.method_43470("§bDamage Dealer"),
                    class_2561.method_43470("Give your pet a damage buff\nthat increases each level"),
                    0, NODE_OFFSET,
                    Set.of(),
                    false,
                    new DamageDealerSkill().getUnlockLevel()
            ),
            new PetSkillNode(
                    SkillRegistry.BACKPACK_BUDDY,
                    new class_1799(class_1802.field_8106),
                    class_2561.method_43470("§bBackpack Buddy"),
                    class_2561.method_43470("Give your pet a backpack to store items"),
                    0, NODE_OFFSET * 2,
                    Set.of(),
                    false,
                    new BackpackBuddySkill().getUnlockLevel()
            ),
            new PetSkillNode(
                    SkillRegistry.GUARDIAN,
                    new class_1799(class_1802.field_8255),
                    class_2561.method_43470("§bGuardian"),
                    class_2561.method_43470("Your pet protects you by taking\nhalf the damage dealt to you"),
                    NODE_OFFSET, NODE_OFFSET,
                    Set.of(SkillRegistry.DAMAGE_DEALER),
                    false,
                    new GuardianSkill().getUnlockLevel()
            ),
            new PetSkillNode(
                    SkillRegistry.ANGEL,
                    new class_1799(class_1802.field_8463),
                    class_2561.method_43470("§bAngel"),
                    class_2561.method_43470("Your pet sacrifices itself to\nrestore your health and\nsave you from a killing blow" +
                            "\nThis can trigger once every 5 minutes"),
                    NODE_OFFSET * 2, NODE_OFFSET,
                    Set.of(SkillRegistry.GUARDIAN),
                    false,
                    new AngelSkill().getUnlockLevel()
            )
    );

    private SkillTreeDefinition() {

    }
}
