package com.reedwellarts.custompets.client.screen;

import com.reedwellarts.custompets.client.networking.snapshot.PetStatsSnapshot;
import com.reedwellarts.custompets.client.screen.skilltree.PetSkillNode;
import com.reedwellarts.custompets.client.screen.skilltree.PetSkillTreeScreen;
import com.reedwellarts.custompets.client.screen.skilltree.SkillTreeDefinition;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_7842;

public class PetStatsScreen extends class_437 {

    private final PetStatsSnapshot stats;

    public PetStatsScreen(PetStatsSnapshot stats){
        super(class_2561.method_43470(stats.name() + "'s Stats"));
        this.stats = stats;
    }

    @Override
    protected void method_25426() {
        int left = field_22789 / 2 - 100;
        int top = field_22790 / 2 - 20;

        class_2561 health = class_2561.method_43470("Health: " + stats.health() + "/" + stats.maxHealth());
        class_2561 level = class_2561.method_43470("Level: " + stats.level());
        class_2561 xp = class_2561.method_43470("XP: " + stats.xp() + "/" + stats.xpToNextLevel());

        method_37063(new class_7842(field_22789 / 2 - (field_22793.method_30880(method_25440().method_30937()) / 2), top - 48,
                field_22793.method_30880(method_25440().method_30937()), 20, method_25440(), field_22793));
        method_37063(new class_7842(field_22789 / 2 - (field_22793.method_30880(health.method_30937()) / 2), top - 36,
                field_22793.method_30880(health.method_30937()), 20, health, field_22793));
        method_37063(new class_7842(field_22789 / 2 - (field_22793.method_30880(level.method_30937()) / 2), top - 24,
                field_22793.method_30880(level.method_30937()), 20, level, field_22793));
        method_37063(new class_7842(field_22789 / 2 - (field_22793.method_30880(xp.method_30937()) / 2), top - 12,
                field_22793.method_30880(xp.method_30937()), 20, xp, field_22793));
        method_37063(class_4185.method_46430(class_2561.method_43470("Skill Tree"), b -> {
            var unlocked = stats.unlockedSkills().stream()
                    .map(class_2960::method_12829)
                    .filter(Objects::nonNull)
                    .collect(Collectors.toSet());

            List<PetSkillNode> nodes = SkillTreeDefinition.ALL.stream()
                    .map(def -> {
                        boolean isUnlocked = unlocked.contains(def.id());

                        return new PetSkillNode(
                                def.id(),
                                def.item(),
                                def.title(),
                                def.description(),
                                def.x(),
                                def.y(),
                                def.parents(),
                                isUnlocked,
                                def.unlockLevel()
                        );
                    })
                    .toList();
            field_22787.method_1507(new PetSkillTreeScreen(stats.petUuid(), nodes, stats.activeSkills()));
        }).method_46434(left, top + 20, 98, 20).method_46431());

        method_37063(class_4185.method_46430(class_2561.method_43470("Close"), b -> method_25419())
                .method_46434(left + 102, top + 20, 98, 20).method_46431());
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float deltaTicks) {
        super.method_25394(context, mouseX, mouseY, deltaTicks);
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
