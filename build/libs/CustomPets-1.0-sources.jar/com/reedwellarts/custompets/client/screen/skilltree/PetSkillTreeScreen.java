package com.reedwellarts.custompets.client.screen.skilltree;

import com.reedwellarts.custompets.client.networking.CustomPetsClientNetworking;
import com.reedwellarts.custompets.pet.skill.PetSkillState;
import java.util.*;
import net.minecraft.class_10799;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_8132;

public class PetSkillTreeScreen extends class_437 {

    private static final class_2960 WINDOW_TEXTURE = class_2960.method_60656("textures/gui/advancements/window.png");
    private static final class_2960 TREE_BG_TEXTURE = class_2960.method_60656("textures/gui/advancements/backgrounds/stone.png");

    private static final int WINDOW_WIDTH = 252;
    private static final int WINDOW_HEIGHT = 140;
    private static final int NODE_W = 26;
    private static final int NODE_H = 26;
    private static final int TREE_X = 9;
    private static final int TREE_Y = 18;
    private static final int TREE_W = 234;
    private static final int TREE_H = 113;

    private final String petUuid;
    private final List<PetSkillNode> nodes = new ArrayList<>();

    private final Set<class_2960> selectedActive = new HashSet<>();

    private final class_8132 layout;

    private double panX = 0;
    private double panY = 0;
    private double zoom = 1.0;
    private boolean dragging = false;
    private double lastMouseX;
    private double lastMouseY;

    public PetSkillTreeScreen(String petUuid, List<PetSkillNode> initialNodes, List<String> initiallyActiveSkills) {
        super(class_2561.method_43470("Pet Skills"));
        this.petUuid = petUuid;
        this.nodes.addAll(initialNodes);
        this.layout = new class_8132(this);

        for (String raw : initiallyActiveSkills){
            class_2960 id = class_2960.method_12829(raw);
            if (id != null){
                selectedActive.add(id);
            }
        }

        selectedActive.removeIf(id -> {
            PetSkillNode node = find(id);
            return node == null || !node.unlocked();
        });
    }

    @Override
    protected void method_25426(){
        int left = (this.field_22789 - WINDOW_WIDTH) / 2;
        int top = (this.field_22790 - WINDOW_HEIGHT) / 2;

        this.layout.method_57726(method_25440(), this.field_22793);
        int y = top + WINDOW_HEIGHT + 5;

        method_37063(class_4185.method_46430(class_2561.method_43470("Close"), b -> method_25419())
                .method_46434(left + 8, y, 60, 20)
                .method_46431()
        );

        method_37063(class_4185.method_46430(class_2561.method_43470("Confirm"), b -> confirm())
                .method_46434(left + WINDOW_WIDTH - 69, y, 60, 20)
                .method_46431()
        );

        centerNodes();
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float deltaTicks) {
        int left = (this.field_22789 - WINDOW_WIDTH) / 2;
        int top = (this.field_22790 - WINDOW_HEIGHT) / 2;

        this.drawWindow(context, left, top);
        this.drawSkillTree(context, left + TREE_X, top + TREE_Y, mouseX, mouseY);

        super.method_25394(context, mouseX, mouseY, deltaTicks);
    }

    public void drawWindow(class_332 context, int x, int y){
        context.method_25290(class_10799.field_56883, WINDOW_TEXTURE, x, y, 0.0F, 0.0F, 252, 140, 256, 256);
        context.method_51439(field_22793, method_25440(), x + 8, y + 6, -12566464, false);
    }

    private void drawSkillTree(class_332 context, int x, int y, int mouseX, int mouseY){
        context.method_44379(x, y, x + TREE_W, y + TREE_H);

        int centerX = x + TREE_W / 2;
        int centerY = y + TREE_H / 2;

        int tile = 16;
        int drawTile = Math.max(1, (int) Math.ceil(tile * zoom));
        double minTreeX = ((x - centerX) / zoom) - panX - tile;
        double maxTreeX = ((x + TREE_W - centerX) / zoom) - panX + tile;
        double minTreeY = ((y - centerY) / zoom) - panY - tile;
        double maxTreeY = ((y + TREE_H - centerY) / zoom) - panY + tile;

        int startTreeX = ((int) Math.floor(minTreeX / tile)) * tile;
        int endTreeX   = ((int) Math.ceil(maxTreeX / tile)) * tile;
        int startTreeY = ((int) Math.floor(minTreeY / tile)) * tile;
        int endTreeY   = ((int) Math.ceil(maxTreeY / tile)) * tile;

        for (int txTree = startTreeX; txTree <= endTreeX; txTree += tile) {
            for (int tyTree = startTreeY; tyTree <= endTreeY; tyTree += tile) {
                int sx = toScreenX(txTree, centerX);
                int sy = toScreenY(tyTree, centerY);
                context.method_25290(
                        class_10799.field_56883,
                        TREE_BG_TEXTURE,
                        sx,
                        sy,
                        0.0F,
                        0.0F,
                        drawTile,
                        drawTile,
                        tile,
                        tile
                );
            }
        }

        int scaledW = (int)(NODE_W * zoom);
        int scaledH = (int)(NODE_H * zoom);

        for (PetSkillNode child : nodes){
            for (class_2960 parentId : child.parents()){
                PetSkillNode parent = find(parentId);
                if (parent == null) continue;

                int x1 = toScreenX(parent.x(), centerX) + scaledW / 2;
                int y1 = toScreenY(parent.y(), centerY) + scaledH / 2;
                int x2 = toScreenX(child.x(), centerX) + scaledW / 2;
                int y2 = toScreenY(child.y(), centerY) + scaledH / 2;

                context.method_51738(Math.min(x1, x2), Math.max(x1, x2), y1, 0xFFFFFFFF);
                context.method_51742(x2, Math.min(y1, y2), Math.max(y1, y2), 0xFFFFFFFF);
            }
        }

        for (PetSkillNode n : nodes){
            int sx = toScreenX(n.x(), centerX);
            int sy = toScreenY(n.y(), centerY);

            boolean selected = selectedActive.contains(n.id());

            int borderSize = 3;
            int scaledBorder = (int)(borderSize * zoom);
            int borderColor = selected ? 0xFF52A535 : 0x0;
            int color = 0xFFDBDBDB;

            if (isHoveringNode(mouseX, mouseY, sx, sy, scaledW, scaledH) && n.unlocked()){
                borderColor = selected ? borderColor : 0xFFFFFFFF;
            }

            if (!n.unlocked()){
                color = 0xFF444444;
            }

            context.method_25294(sx - scaledBorder, sy - scaledBorder, sx + scaledW + scaledBorder, sy + scaledH + scaledBorder, borderColor);
            context.method_25294(sx, sy, sx + scaledW, sy + scaledH, color);

            context.method_51448().pushMatrix();
            float itemScale = (float) zoom;

            float centerItemX = sx + scaledW / 2f;
            float centerItemY = sy + scaledH / 2f;

            context.method_51448().translate(centerItemX, centerItemY);
            context.method_51448().scale(itemScale, itemScale);

            context.method_51427(n.item(), -8, -8);
            context.method_51448().popMatrix();

            if (isHoveringNode(mouseX, mouseY, sx, sy, scaledW,scaledH)){
                List<class_2561> tooltip = new ArrayList<>();
                tooltip.add(n.title());

                String[] lines = n.description().getString().split("\\n");
                for (String line : lines) {
                    tooltip.add(class_2561.method_43470(line));
                }

                if (n.unlocked()){
                    tooltip.add(class_2561.method_43470(selected ? "§aActive (click to deactivate)" : "§cInactive (click to activate)"));
                } else {
                    tooltip.add(class_2561.method_43470("§8Locked (Unlocked at level " + n.unlockLevel() + ")"));
                }

                context.method_51434(field_22793, tooltip, mouseX, mouseY);
            }
        }

        context.method_44380();
    }

    private PetSkillNode find(class_2960 id){
        for (PetSkillNode n : nodes) if (n.id().equals(id)) return n;
        return null;
    }

    private int toScreenX(int treeX, int centerX){
        return (int) (centerX + (treeX + panX) * zoom);
    }

    private int toScreenY(int treeY, int centerY){
        return (int) (centerY + (treeY + panY) * zoom);
    }

    private boolean isHoveringNode(int mouseX, int mouseY, int x, int y, int w, int h){
        return mouseX >= x && mouseX <= x + w && mouseY >= y && mouseY <= y + h;
    }

    private void confirm(){
        List<String> active = selectedActive.stream()
                .map(class_2960::toString)
                .toList();

        CustomPetsClientNetworking.setPetActiveSkills(petUuid, active);
        method_25419();
    }

    private boolean isInTreeViewport(double mouseX, double mouseY){
        int left = (this.field_22789 - WINDOW_WIDTH) / 2;
        int top = (this.field_22790 - WINDOW_HEIGHT) / 2;

        int x1 = left + TREE_X;
        int y1 = top + TREE_Y;
        int x2 = x1 + TREE_W;
        int y2 = y1 + TREE_H;

        return mouseX >= x1 && mouseX < x2 && mouseY >= y1 && mouseY < y2;
    }

    @Override
    public boolean method_25402(class_11909 click, boolean doubled) {
        if (click.method_74245() == 0){
            if (tryToggleNode(click.comp_4798(), click.comp_4799())) return true;

            if (isInTreeViewport(click.comp_4798(), click.comp_4799())) {
                dragging = true;
                lastMouseX = click.comp_4798();
                lastMouseY = click.comp_4799();
            }
        }
        return super.method_25402(click, doubled);
    }

    @Override
    public boolean method_25406(class_11909 click) {
        if (click.method_74245() == 0) dragging = false;
        return super.method_25406(click);
    }

    @Override
    public boolean method_25403(class_11909 click, double offsetX, double offsetY) {
        if (dragging && click.method_74245() == 0){
            panX += (click.comp_4798() - lastMouseX);
            panY += (click.comp_4799() - lastMouseY);
            lastMouseX = click.comp_4798();
            lastMouseY = click.comp_4799();
            return true;
        }
        return super.method_25403(click, offsetX, offsetY);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        double factor = verticalAmount > 0 ? 1.1 : 0.9;
        zoom = Math.clamp(zoom * factor, 0.5, 2.5);
        return true;
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    private boolean tryToggleNode(double mouseX, double mouseY){
        int left = (this.field_22789 - WINDOW_WIDTH) / 2;
        int top = (this.field_22790 - WINDOW_HEIGHT) / 2;
        int centerX = left + TREE_X + TREE_W / 2;
        int centerY = top + TREE_Y + TREE_H / 2;
        int scaledW = (int)(NODE_W * zoom);
        int scaledH = (int)(NODE_H * zoom);

        for (PetSkillNode n : nodes){
            int sx = toScreenX(n.x(), centerX);
            int sy = toScreenY(n.y(), centerY);

            if (!isHoveringNode((int)mouseX, (int)mouseY, sx, sy, scaledW, scaledH)) continue;

            if (!n.unlocked()) return true;

            if (selectedActive.contains(n.id())){
                selectedActive.remove(n.id());
                return true;
            }

            if (selectedActive.size() >= PetSkillState.MAX_ACTIVE){
                return true;
            }

            selectedActive.add(n.id());
            return true;
        }

        return false;
    }

    private void centerNodes(){
        if (nodes.isEmpty()) return;

        List<PetSkillNode> roots = nodes.stream()
                .filter(n -> n.parents().isEmpty())
                .toList();

        int minRootY = roots.stream().mapToInt(PetSkillNode::y).min().getAsInt();
        int maxRootY = roots.stream().mapToInt(PetSkillNode::y).max().getAsInt();

        int centerRootY = (minRootY + maxRootY) / 2;

        panX = -(TREE_W / 2.0) + NODE_W;
        panY = -(centerRootY / 2.0);
    }
}
