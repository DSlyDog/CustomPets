package com.reedwellarts.custompets.items.item;

import com.reedwellarts.custompets.pet.core.interfaces.OwnablePet;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_3222;
import com.reedwellarts.custompets.networking.CustomPetsServerNetworking;

public class PetNameTagItem extends class_1792 {

    public PetNameTagItem(class_1793 settings) {
        super(settings);
    }

    @Override
    public class_1269 method_7847(class_1799 stack, class_1657 user, class_1309 entity, class_1268 hand) {
        if (user.method_73183().method_8608()) return class_1269.field_5811;

        if (!(entity instanceof OwnablePet pet)) return class_1269.field_5811;

        if (pet.getDelegate().getPetOwnerUuid() == null || !pet.getDelegate().getPetOwnerUuid().equals(user.method_5667())) return class_1269.field_5811;

        CustomPetsServerNetworking.sendOpenScreen((class_3222) user, entity.method_5845());
        return class_1269.field_5812;
    }
}
