package com.reedwellarts.custompets.items.item;

import com.reedwellarts.custompets.event_handlers.state.PetTrackingState;
import com.reedwellarts.custompets.networking.CustomPetsServerNetworking;
import com.reedwellarts.custompets.networking.payloads.SendPetStatsSnapshotPayload;
import com.reedwellarts.custompets.pet.core.interfaces.OwnablePet;
import com.reedwellarts.custompets.pet.core.interfaces.Skill;
import com.reedwellarts.custompets.pet.data.PetData;
import com.reedwellarts.custompets.pet.data.PlayerPetTracking;
import com.reedwellarts.custompets.pet.skill.PetSkillState;
import com.reedwellarts.custompets.util.CustomPetsConfig;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.minecraft.class_1308;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_7923;

public class PetWand {

    public static void openRosterScreen(class_3222 owner, class_3218 world){
        List<SendPetStatsSnapshotPayload.PetSnapshot> snapshots = new ArrayList<>();
        PetTrackingState trackingState = PetTrackingState.get(world);

        for (OwnablePet pet : trackingState.getPlayerPetEntities(owner.method_5667())){
            class_1308 petEntity = (class_1308) pet;
            PetData petData = pet.getDelegate().getDataManager().getData();
            PetSkillState skillState = pet.getDelegate().getDataManager().getSkillState();

            List<String> unlockedSkills = new ArrayList<>();
            for (class_2960 id : skillState.getUnlocked()){
                unlockedSkills.add(id.toString());
            }

            List<String> activeSkills = new ArrayList<>();
            for (class_2960 id : skillState.getActive()){
                activeSkills.add(id.toString());
            }

            snapshots.add(new SendPetStatsSnapshotPayload.PetSnapshot(
                    petEntity.method_5667().toString(),
                    class_7923.field_41177.method_10221(pet.getBaseType()).toString(),
                    petData.name,
                    petData.health,
                    petData.maxHealth,
                    petData.level,
                    petData.xp,
                    petData.xpToNextLevel,
                    unlockedSkills,
                    activeSkills,
                    trackingState.isActivePet(owner.method_5667(), petEntity.method_5667())
            ));

            CustomPetsServerNetworking.sendPetStatsSnapshot(owner, snapshots, CustomPetsConfig.MAX_ACTIVE);
        }
    }
}
