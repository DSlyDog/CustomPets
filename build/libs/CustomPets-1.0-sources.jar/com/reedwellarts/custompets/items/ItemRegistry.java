package com.reedwellarts.custompets.items;

import com.reedwellarts.custompets.CustomPets;
import com.reedwellarts.custompets.items.item.PetNameTagItem;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7706;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import java.util.function.Function;

public class ItemRegistry {

    public static final class_1792 PET_NAME_TAG = register(
      "pet_name_tag",
      PetNameTagItem::new,
      new class_1792.class_1793().method_7889(1)
    );

    private static class_1792 register(String name, Function<class_1792.class_1793, class_1792> factory, class_1792.class_1793 settings){
        class_2960 id = class_2960.method_60655(CustomPets.MOD_ID, name);
        class_5321<class_1792> key = class_5321.method_29179(class_7924.field_41197, id);
        class_1792 item = factory.apply(settings.method_63686(key));
        return class_2378.method_39197(class_7923.field_41178, key, item);
    }

    public static void registerModItems(){
        CustomPets.LOGGER.info("Registering items for {}", CustomPets.MOD_ID);

        ItemGroupEvents.modifyEntriesEvent(class_7706.field_41060).register(entries ->
                entries.method_45421(PET_NAME_TAG)
        );
    }
}
