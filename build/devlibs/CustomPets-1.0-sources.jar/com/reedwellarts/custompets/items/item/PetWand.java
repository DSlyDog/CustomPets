package com.reedwellarts.custompets.items.item;

import com.reedwellarts.custompets.event_handlers.state.PetTrackingState;
import com.reedwellarts.custompets.networking.CustomPetsServerNetworking;
import com.reedwellarts.custompets.networking.payloads.SendPetStatsSnapshotPayload;
import com.reedwellarts.custompets.pet.core.interfaces.OwnablePet;
import com.reedwellarts.custompets.pet.core.interfaces.Skill;
import com.reedwellarts.custompets.pet.data.PetData;
import com.reedwellarts.custompets.pet.data.PlayerPetTracking;
import com.reedwellarts.custompets.pet.skill.PetSkillState;
import com.reedwellarts.custompets.util.CustomPetsConfig;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtHelper;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.storage.NbtReadView;
import net.minecraft.storage.ReadView;
import net.minecraft.util.ErrorReporter;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class PetWand {

    public static void openRosterScreen(ServerPlayerEntity owner, ServerWorld world){
        List<SendPetStatsSnapshotPayload.PetSnapshot> snapshots = new ArrayList<>();
        PetTrackingState trackingState = PetTrackingState.get(world);

        for (OwnablePet pet : trackingState.getPlayerPetEntities(owner.getUuid())){
            MobEntity petEntity = (MobEntity) pet;
            PetData petData = pet.getDelegate().getDataManager().getData();
            PetSkillState skillState = pet.getDelegate().getDataManager().getSkillState();

            List<String> unlockedSkills = new ArrayList<>();
            for (Identifier id : skillState.getUnlocked()){
                unlockedSkills.add(id.toString());
            }

            List<String> activeSkills = new ArrayList<>();
            for (Identifier id : skillState.getActive()){
                activeSkills.add(id.toString());
            }

            snapshots.add(new SendPetStatsSnapshotPayload.PetSnapshot(
                    petEntity.getUuid().toString(),
                    Registries.ENTITY_TYPE.getId(pet.getBaseType()).toString(),
                    petData.name,
                    petData.health,
                    petData.maxHealth,
                    petData.level,
                    petData.xp,
                    petData.xpToNextLevel,
                    unlockedSkills,
                    activeSkills,
                    trackingState.isActivePet(owner.getUuid(), petEntity.getUuid())
            ));

            CustomPetsServerNetworking.sendPetStatsSnapshot(owner, snapshots, CustomPetsConfig.MAX_ACTIVE);
        }
    }
}
