package com.reedwellarts.custompets.pet.data;

import com.reedwellarts.custompets.CustomPets;
import java.util.*;

public class PlayerPetTracking {

    public static final Map<UUID, List<UUID>> playerPets = new HashMap<>();
    public static final Map<UUID, List<UUID>> playerActivePets = new HashMap<>();

    private static final int MAX_TAMED_PETS = 20;
    private static final int MAX_ACTIVE_PETS = 4;

    public static boolean playerAtMaxPets(UUID player){
        if (!playerPets.containsKey(player)) playerPets.put(player, new ArrayList<>());
        return playerPets.get(player).size() >= MAX_TAMED_PETS;
    }

    public static boolean playerAtMaxActive(UUID player){
        if (!playerActivePets.containsKey(player)) playerActivePets.put(player, new ArrayList<>());
        return playerActivePets.get(player).size() >= MAX_ACTIVE_PETS;
    }

    public static void playerTamePet(UUID player, UUID petUuid){
        playerPets.get(player).add(petUuid);
        playerActivePets.get(player).add(petUuid);
    }

    public static List<UUID> getPlayerActivePets(UUID player){
        return playerActivePets.get(player);
    }

    public static void respawnPet(UUID player, UUID petUuid){
        if (!playerActivePets.containsKey(player)) playerActivePets.put(player, new ArrayList<>());
        if (!playerPets.containsKey(player)) playerPets.put(player, new ArrayList<>());

        if (!playerActivePets.get(player).contains(petUuid)) playerActivePets.get(player).add(petUuid);
        if (!playerPets.get(player).contains(petUuid)) playerPets.get(player).add(petUuid);
    }
}
