package com.reedwellarts.custompets.event_handlers;

import com.reedwellarts.custompets.CustomPets;
import com.reedwellarts.custompets.pet.core.interfaces.OwnablePet;
import com.reedwellarts.custompets.pet.data.PlayerPetTracking;
import net.minecraft.entity.Entity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

import java.util.List;
import java.util.UUID;

public class PlayerKillEventHandler {

    public static void handleAfterDeath(Entity entity, DamageSource source){
        if (source.getAttacker() instanceof ServerPlayerEntity player){
            List<UUID> ownablePets = PlayerPetTracking.getPlayerActivePets(player.getUuid());
            for (UUID petUuid : ownablePets){
                Entity petEntity = player.getEntityWorld().getEntity(petUuid);
                if (petEntity instanceof OwnablePet pet) {
                    boolean petHit = pet.getDelegate().onPlayerKilledTarget(entity);
                }
            }
        }
    }
}
