package com.reedwellarts.custompets.event_handlers;

import com.reedwellarts.custompets.event_handlers.state.PetTrackingState;
import com.reedwellarts.custompets.pet.core.interfaces.OwnablePet;
import com.reedwellarts.custompets.pet.data.PlayerPetTracking;
import com.reedwellarts.custompets.pet.entities.PetFoxEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.registry.Registries;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;

public class RespawnEventHandler {

    public static void handlePetRespawn(MinecraftServer server){
        for (ServerWorld world : server.getWorlds()){
            PetTrackingState state = PetTrackingState.get(world);
            long now = world.getTime();

            List<PetTrackingState.Entry> due = new ArrayList<>();
            for (PetTrackingState.Entry entry : state.entries()){
                if (entry.respawnAt <= now){
                    ServerPlayerEntity owner = server.getPlayerManager().getPlayer(entry.ownerUuid);
                    if (owner == null) continue;

                    Identifier id = Identifier.tryParse(entry.petTypeId);
                    if (id == null) continue;

                    EntityType type = Registries.ENTITY_TYPE.get(id);
                    if (type == null) continue;

                    LivingEntity living = buildEntity(entry, world, owner);

                    world.spawnEntity(living);
                    due.add(entry);
                }
            }
            state.removeMultiple(due);
        }
    }

    public static LivingEntity buildEntity(PetTrackingState.Entry entry, ServerWorld world, ServerPlayerEntity owner){
        Entity loadedEntity = EntityType.loadEntityWithPassengers(
                entry.petNbt, world, SpawnReason.EVENT, entity -> {
                    entity.refreshPositionAndAngles(owner.getX() + 1, owner.getY(), owner.getZ() + 1, owner.getYaw(), 0f);
                    return entity;
                }
        );
        if (!(loadedEntity instanceof LivingEntity living)) return null;

        if (living instanceof OwnablePet pet) {
            pet.getDelegate().setPetOwnerUuid(owner.getUuid());
            pet.setPetSitting(false);
            living.getAttributeInstance(EntityAttributes.MAX_HEALTH).setBaseValue(pet.getDelegate().getDataManager().getData().maxHealth);
            living.setHealth(living.getMaxHealth());
            pet.getDelegate().setPetHealth((int) living.getMaxHealth());
            living.setVelocity(living.getVelocity().x, 0, living.getVelocity().z);

            if (!PlayerPetTracking.playerAtMaxPets(owner.getUuid()) && !PlayerPetTracking.playerAtMaxActive(owner.getUuid())){
                PlayerPetTracking.respawnPet(owner.getUuid(), loadedEntity.getUuid());
            }
        }

        if (entry.customNameJson != null && !entry.customNameJson.isBlank()){
            living.setCustomName(Text.literal(entry.customNameJson));
            living.setCustomNameVisible(true);
        }

        if (living instanceof PetFoxEntity foxPet && entry.petVariant != null){
            foxPet.applySavedVariant(entry.petVariant.toUpperCase());
        }

        return living;
    }
}
