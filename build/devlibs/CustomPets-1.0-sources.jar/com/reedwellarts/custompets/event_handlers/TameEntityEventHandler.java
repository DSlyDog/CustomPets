package com.reedwellarts.custompets.event_handlers;

import com.reedwellarts.custompets.event_handlers.state.PetTrackingState;
import com.reedwellarts.custompets.pet.converters.FoxPetConverter;
import com.reedwellarts.custompets.pet.core.interfaces.OwnablePet;
import com.reedwellarts.custompets.pet.core.interfaces.PetConverter;
import com.reedwellarts.custompets.pet.data.PlayerPetTracking;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.storage.NbtWriteView;
import net.minecraft.util.ActionResult;
import net.minecraft.util.ErrorReporter;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.world.World;

import java.util.Map;
import java.util.UUID;

public class TameEntityEventHandler {

    private static final Map<EntityType<?>, PetConverter<?, ?>> CONVERTERS = Map.of(
            EntityType.FOX, new FoxPetConverter()
            //EntityType.ENDER_DRAGON, new DragonPetConverter()
    );

    public static ActionResult handleUseEntity(PlayerEntity player, World world, Hand hand, Entity entity, EntityHitResult hitResult) {
        if (world.isClient()) return ActionResult.PASS;
        if (hand != Hand.MAIN_HAND) return ActionResult.PASS;
        if (!player.getMainHandStack().isOf(Items.STICK)) return ActionResult.PASS;

        if (!(entity instanceof LivingEntity living)) return ActionResult.PASS;

        PetConverter<?, ?> raw = CONVERTERS.get(living.getType());
        if (raw == null) return ActionResult.PASS;

        return convert(player, world, living, raw);
    }

    @SuppressWarnings("unchecked")
    private static <S extends LivingEntity, P extends LivingEntity & OwnablePet>
    ActionResult convert(PlayerEntity player, World world, LivingEntity srcAny, PetConverter<?, ?> raw){
        PetConverter<S, P> converter = (PetConverter<S, P>) raw;
        S src = (S) srcAny;

        P pet = converter.petType().create(world, SpawnReason.CONVERSION);
        if (pet == null) return ActionResult.PASS;

        converter.copyCommon(src, pet, player);
        converter.copySpecific(src, pet);

        boolean success = registerPet(pet, player.getUuid(), pet.getUuid(), (ServerWorld) world);
        if (!success) {
            return ActionResult.PASS;
        }

        world.spawnEntity(pet);
        src.discard();
        return ActionResult.SUCCESS;
    }

    private static boolean registerPet(LivingEntity pet, UUID player, UUID petUuid, ServerWorld world){
        PetTrackingState trackingState = PetTrackingState.get(world);
        if (!trackingState.playerAtMaxPets(player) && !trackingState.playerAtMaxActive(player)){
            trackingState.addActivePet(player, petUuid);

            PetTrackingState.Entry entry = new PetTrackingState.Entry();
            if (pet.hasCustomName())
                entry.customNameJson = pet.getCustomName().getString();
            entry.ownerUuid = player;
            entry.petTypeId = EntityType.getId(pet.getType()).toString();
            entry.petUuid = pet.getUuid();
            NbtWriteView view = NbtWriteView.create(ErrorReporter.EMPTY);
            pet.writeData(view);
            NbtCompound nbt = view.getNbt();
            nbt.putString("id", EntityType.getId(pet.getType()).toString());
            entry.petNbt = nbt;

            trackingState.addPlayerPet(player,  entry);
            trackingState.addPetEntity(player, (OwnablePet) pet);
            return true;
        }

        return false;
    }
}
