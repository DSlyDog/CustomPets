package com.reedwellarts.custompets.event_handlers.state;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.reedwellarts.custompets.CustomPets;
import com.reedwellarts.custompets.event_handlers.RespawnEventHandler;
import com.reedwellarts.custompets.pet.core.interfaces.OwnablePet;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Uuids;
import net.minecraft.world.PersistentState;
import net.minecraft.world.PersistentStateType;
import org.jspecify.annotations.Nullable;

import java.util.*;

public class PetTrackingState extends PersistentState {

    public static class Entry{
        public UUID ownerUuid;
        public UUID petUuid;
        public String petTypeId;
        public long respawnAt;
        public @Nullable String customNameJson;
        public @Nullable String petVariant;
        public NbtCompound petNbt;

        public static final Codec<Entry> CODEC = RecordCodecBuilder.create(instance -> instance.group(
                Uuids.CODEC.fieldOf("owner_uuid").forGetter(e -> e.ownerUuid),
                Uuids.CODEC.fieldOf("pet_uuid").forGetter(e -> e.petUuid),
                Codec.STRING.fieldOf("pet_type_id").forGetter(e -> e.petTypeId),
                Codec.LONG.fieldOf("respawn_at").forGetter(e -> e.respawnAt),
                Codec.STRING.optionalFieldOf("custom_name_json", "")
                        .forGetter(e -> e.customNameJson == null ? "" : e.customNameJson),
                Codec.STRING.optionalFieldOf("pet_variant", "")
                        .forGetter(e -> e.petVariant == null ? "" : e.petVariant),
                NbtCompound.CODEC.fieldOf("pet_nbt").forGetter(e -> e.petNbt)
        ).apply(instance, (ownerUuid, petUuid, petTypeId, respawnAt, customNameJson, petVariant, petNbt) -> {
            Entry e = new Entry();
            e.ownerUuid = ownerUuid;
            e.petUuid = petUuid;
            e.petTypeId = petTypeId;
            e.respawnAt = respawnAt;
            e.customNameJson = customNameJson.isEmpty() ? null : customNameJson;
            e.petVariant = petVariant.isEmpty() ? null : petVariant;
            e.petNbt = petNbt.isEmpty() ? null : petNbt;
            return e;
        }));
    }

    private static final String SAVE_ID = CustomPets.MOD_ID + "_links";
    private static final Codec<PetTrackingState> CODEC = RecordCodecBuilder.create(instance -> instance.group(
       Entry.CODEC.listOf().fieldOf("entries").forGetter(state -> state.entries)
    ).apply(instance, list -> {
        PetTrackingState state = new PetTrackingState();
        state.entries.addAll(list);
        return state;
    }));
    private static final PersistentStateType<PetTrackingState> TYPE = new PersistentStateType<>(
            SAVE_ID,
            PetTrackingState::new,
            CODEC,
            null
    );

    private static final int MAX_TAMED_PETS = 20;
    private static final int MAX_ACTIVE_PETS = 4;

    private final List<Entry> entries = new ArrayList<>();
    private final Map<UUID, List<Entry>> playerPets = new HashMap<>();
    private final Map<UUID, List<OwnablePet>> playerPetEntities = new HashMap<>();
    private final Map<UUID, List<UUID>> playerActivePets = new HashMap<>();

    public static PetTrackingState get(ServerWorld world){
        return world.getPersistentStateManager().getOrCreate(TYPE);
    }

    public void add(Entry e){
        entries.add(e);
        markDirty();
    }

    public List<Entry> entries(){
        return entries;
    }

    public void removeMultiple(List<Entry> due){
        this.entries.removeAll(due);
        markDirty();
    }

    public void addPlayerPet(UUID playerUuid, Entry e){
        if (this.playerPets.containsKey(playerUuid)) {
            this.playerPets.get(playerUuid).add(e);
        }else{
            List<Entry> pets = new ArrayList<>();
            pets.add(e);
            this.playerPets.put(playerUuid, pets);
        }
        markDirty();
    }

    public void addActivePet(UUID playerUuid, UUID petUuid){
        if (!this.playerActivePets.containsKey(playerUuid)){
            List<UUID> pets = new ArrayList<>();
            this.playerActivePets.put(playerUuid, pets);
        }

        playerActivePets.get(playerUuid).add(petUuid);
    }

    public void addPetEntity(UUID playerUuid, OwnablePet pet){
        if (!this.playerPetEntities.containsKey(playerUuid)){
            List<OwnablePet> pets = new ArrayList<>();
            this.playerPetEntities.put(playerUuid, pets);
        }

        this.playerPetEntities.get(playerUuid).add(pet);
    }

    public Entry getPlayerPet(UUID playerUuid, UUID petUuid){
        if (!this.playerPets.containsKey(playerUuid)) return null;

        List<Entry> pets = playerPets.get(playerUuid);

        for (Entry pet : pets){
            if (pet.petUuid.equals(petUuid)){
                return pet;
            }
        }
        return null;
    }

    public List<Entry> getPlayerPets(UUID playerUuid){
        if (!this.playerPets.containsKey(playerUuid)){
            List<Entry> entries = new ArrayList<>();
            this.playerPets.put(playerUuid, entries);
        }

        return this.playerPets.get(playerUuid);
    }

    public List<OwnablePet> getPlayerPetEntities(UUID playerUuid){
        if (!this.playerPetEntities.containsKey(playerUuid)){
            List<OwnablePet> ownables = new ArrayList<>();
            this.playerPetEntities.put(playerUuid, ownables);
        }

        return this.playerPetEntities.get(playerUuid);
    }

    public boolean isActivePet(UUID playerUuid, UUID petUuid){
        if (!this.playerActivePets.containsKey(playerUuid)){
            List<UUID> entries = new ArrayList<>();
            this.playerActivePets.put(playerUuid, entries);
        }

        return this.playerActivePets.get(playerUuid).contains(petUuid);
    }

    public void updateActivePets(UUID ownerUuid, List<String> petUuids, ServerWorld world){
        if (!this.playerActivePets.containsKey(ownerUuid)){
            List<UUID> petList = new ArrayList<>();
            this.playerActivePets.put(ownerUuid, petList);
        }

        List<UUID> currentActive = this.playerActivePets.get(ownerUuid);
        List<UUID> newUuids = new ArrayList<>();

        for (String stringUuid : petUuids){
            newUuids.add(UUID.fromString(stringUuid));
        }

        this.playerActivePets.put(ownerUuid, newUuids);

        for (UUID uuid : currentActive){
            if (!newUuids.contains(uuid)) {
                Entity entity = world.getEntity(uuid);
                if (entity != null) entity.discard();
            }
        }

        ServerPlayerEntity owner = (ServerPlayerEntity) world.getPlayerByUuid(ownerUuid);

        CustomPets.LOGGER.info("Pet entities size: {}", this.playerPetEntities.get(ownerUuid));

        for (OwnablePet pet : this.playerPetEntities.get(ownerUuid)){
            LivingEntity livingPet = (LivingEntity) pet;
            if (!currentActive.contains(livingPet.getUuid()) && newUuids.contains(livingPet.getUuid())){
                livingPet.refreshPositionAndAngles(owner.getX() + 1, owner.getY(), owner.getZ() + 1, owner.getYaw(), 0f);
                livingPet.setVelocity(livingPet.getVelocity().x, 0, livingPet.getVelocity().z);
                pet.unsetPetRemoved();
                world.spawnEntity(livingPet);
            }
        }

        markDirty();
    }

    public boolean playerAtMaxPets(UUID player){
        if (!playerPets.containsKey(player)) playerPets.put(player, new ArrayList<>());
        return playerPets.get(player).size() >= MAX_TAMED_PETS;
    }

    public boolean playerAtMaxActive(UUID player){
        if (!playerActivePets.containsKey(player)) playerActivePets.put(player, new ArrayList<>());
        return playerActivePets.get(player).size() >= MAX_ACTIVE_PETS;
    }
}
