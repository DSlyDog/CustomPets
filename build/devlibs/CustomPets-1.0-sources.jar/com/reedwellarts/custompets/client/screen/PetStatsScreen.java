package com.reedwellarts.custompets.client.screen;

import com.reedwellarts.custompets.client.networking.snapshot.PetStatsSnapshot;
import com.reedwellarts.custompets.client.screen.skilltree.PetSkillNode;
import com.reedwellarts.custompets.client.screen.skilltree.PetSkillTreeScreen;
import com.reedwellarts.custompets.client.screen.skilltree.SkillTreeDefinition;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

public class PetStatsScreen extends Screen {

    private final PetStatsSnapshot stats;

    public PetStatsScreen(PetStatsSnapshot stats){
        super(Text.literal(stats.name() + "'s Stats"));
        this.stats = stats;
    }

    @Override
    protected void init() {
        int left = width / 2 - 100;
        int top = height / 2 - 20;

        Text health = Text.literal("Health: " + stats.health() + "/" + stats.maxHealth());
        Text level = Text.literal("Level: " + stats.level());
        Text xp = Text.literal("XP: " + stats.xp() + "/" + stats.xpToNextLevel());

        addDrawableChild(new TextWidget(width / 2 - (textRenderer.getWidth(getTitle().asOrderedText()) / 2), top - 48,
                textRenderer.getWidth(getTitle().asOrderedText()), 20, getTitle(), textRenderer));
        addDrawableChild(new TextWidget(width / 2 - (textRenderer.getWidth(health.asOrderedText()) / 2), top - 36,
                textRenderer.getWidth(health.asOrderedText()), 20, health, textRenderer));
        addDrawableChild(new TextWidget(width / 2 - (textRenderer.getWidth(level.asOrderedText()) / 2), top - 24,
                textRenderer.getWidth(level.asOrderedText()), 20, level, textRenderer));
        addDrawableChild(new TextWidget(width / 2 - (textRenderer.getWidth(xp.asOrderedText()) / 2), top - 12,
                textRenderer.getWidth(xp.asOrderedText()), 20, xp, textRenderer));
        addDrawableChild(ButtonWidget.builder(Text.literal("Skill Tree"), b -> {
            var unlocked = stats.unlockedSkills().stream()
                    .map(Identifier::tryParse)
                    .filter(Objects::nonNull)
                    .collect(Collectors.toSet());

            List<PetSkillNode> nodes = SkillTreeDefinition.ALL.stream()
                    .map(def -> {
                        boolean isUnlocked = unlocked.contains(def.id());

                        return new PetSkillNode(
                                def.id(),
                                def.item(),
                                def.title(),
                                def.description(),
                                def.x(),
                                def.y(),
                                def.parents(),
                                isUnlocked,
                                def.unlockLevel()
                        );
                    })
                    .toList();
            client.setScreen(new PetSkillTreeScreen(stats.petUuid(), nodes, stats.activeSkills()));
        }).dimensions(left, top + 20, 98, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Close"), b -> close())
                .dimensions(left + 102, top + 20, 98, 20).build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float deltaTicks) {
        super.render(context, mouseX, mouseY, deltaTicks);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
