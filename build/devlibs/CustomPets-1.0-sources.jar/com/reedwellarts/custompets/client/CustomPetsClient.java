package com.reedwellarts.custompets.client;

import com.reedwellarts.custompets.CustomPets;
import com.reedwellarts.custompets.client.networking.CustomPetsClientNetworking;
import com.reedwellarts.custompets.pet.core.ModEntities;
import com.reedwellarts.custompets.pet.core.interfaces.OwnablePet;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.render.entity.EntityRendererFactories;
import net.minecraft.client.render.entity.FoxEntityRenderer;
import net.minecraft.entity.Entity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CustomPetsClient implements ClientModInitializer {

    public static final String MOD_ID = "custompets";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitializeClient() {
        EntityRendererFactories.register(ModEntities.PET_FOX_ENTITY, FoxEntityRenderer::new);

        CustomPetsClientNetworking.register();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player != null && client.player.getVehicle() instanceof OwnablePet pet && pet.isFlyable()){
                if (client.options.sneakKey.isPressed()){
                    if (((Entity) pet).isOnGround()){
                        LOGGER.info("Client sees dismount");
                        client.player.dismountVehicle();
                        pet.setFlightDescending(false);
                        ((Entity) pet).removeAllPassengers();
                        CustomPetsClientNetworking.sendDismountNotice(((Entity) pet).getUuidAsString());
                    }else {
                        pet.setFlightDescending(true);
                    }
                }else{
                    pet.setFlightDescending(false);
                }
            }
        });
    }
}
